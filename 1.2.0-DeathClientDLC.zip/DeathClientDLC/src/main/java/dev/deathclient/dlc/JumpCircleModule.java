package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

/**
 * Jump Circle: when you jump, a soft glowing ring (textures/gui/ring.png) is laid on the ground at your feet.
 * Five modes: Expand (spreads out and fades), Pulse (a breathing ring), Collapse (starts wide and shrinks
 * onto your feet), Ripple (three waves one after another), Rise (rings lift off the ground one after another).
 *
 * The ring is drawn as a screen overlay, glued to the ground plane: the texture is cut into thin horizontal
 * strips, every strip placed by projecting the matching ground line, which gives the correct perspective.
 */
public class JumpCircleModule extends Module {
    private static final Identifier TEXTURE = Identifier.of("deathclientdlc", "textures/gui/ring.png");
    private static final int TEX = 256;
    /** The ring's soft outer edge sits at this fraction of the texture's half-size. */
    private static final double OUTER = 0.89;
    private static final int MAX_CIRCLES = 6;
    private static final double GROW_SECONDS = 0.30;
    private static final int EXPAND = 1, PULSE = 2, COLLAPSE = 3, RIPPLE = 4, RISE = 5;

    public final NumberSetting mode = add(new NumberSetting("Mode", 1, 1, 5, 1)
            .labels("Expand", "Pulse", "Collapse", "Ripple", "Rise"));
    /** Radius of the ring's outer edge at full size, in blocks. */
    public final NumberSetting radius = add(new NumberSetting("Radius", 1.5, 0.5, 4.0, 0.1));
    public final NumberSetting duration = add(new NumberSetting("Duration", 1.2, 0.4, 3.0, 0.1));
    public final NumberSetting opacity = add(new NumberSetting("Opacity", 90, 10, 100, 5));
    /** Strips per ring: more is smoother and a little heavier. */
    public final NumberSetting quality = add(new NumberSetting("Quality", 40, 20, 64, 4));
    public final BoolSetting themeColor = add(new BoolSetting("Theme color", true));

    private record Circle(double x, double y, double z, long start) {}

    private final List<Circle> circles = new ArrayList<>();
    private final ScreenProjector proj = new ScreenProjector();
    private boolean wasOnGround;

    public JumpCircleModule() { super("Jump Circle", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        boolean onGround = p.isOnGround();
        if (wasOnGround && !onGround && p.getVelocity().y > 0.1) {
            circles.add(new Circle(p.getX(), p.getY() + 0.03, p.getZ(), System.nanoTime()));
            if (circles.size() > MAX_CIRCLES) circles.remove(0);
        }
        wasOnGround = onGround;
    }

    @Override
    protected void onDisable() { circles.clear(); }

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        JumpCircleModule m = ModuleManager.get(JumpCircleModule.class);
        if (m == null || !m.isEnabled() || m.circles.isEmpty() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        m.draw(ctx, c, tickCounter.getTickProgress(false));
    }

    private void draw(DrawContext ctx, MinecraftClient c, float delta) {
        proj.begin(c, delta);
        long now = System.nanoTime();
        double life = duration.get(), op = opacity.get() / 100.0, r = radius.get();
        int rgb = (themeColor.get() ? Theme.current().accent() : 0xFFFFFF) & 0xFFFFFF;
        int m = (int) mode.get();

        circles.removeIf(ci -> (now - ci.start()) / 1.0e9 > life * 1.1);

        for (Circle ci : circles) {
            double age = (now - ci.start()) / 1.0e9;
            double t = Math.min(1.0, age / life);                    // 0..1 over the lifetime
            double fadeIn = Math.min(1.0, age / 0.06);
            switch (m) {
                case EXPAND -> {
                    double grow = Math.min(1.0, age / GROW_SECONDS);
                    double ease = 1 - Math.pow(1 - grow, 3);          // fast start, soft landing
                    ring(ctx, ci, r * ease * (1.0 + 0.12 * t), 0, fadeIn * Math.pow(1 - t, 1.3) * op, rgb);
                }
                case PULSE -> {
                    double grow = Math.min(1.0, age / GROW_SECONDS);
                    double ease = 1 - Math.pow(1 - grow, 3);
                    double throb = 1.0 + 0.12 * Math.sin(age * 10.0);
                    double glow = 0.8 + 0.2 * Math.sin(age * 10.0 + 1.0);
                    ring(ctx, ci, r * (0.6 + 0.4 * ease) * throb, 0, fadeIn * (1 - t) * glow * op, rgb);
                }
                case COLLAPSE -> {
                    double e = 1 - Math.pow(1 - Math.min(1.0, t * 1.1), 2);
                    ring(ctx, ci, r * (1.35 - 1.05 * e), 0, Math.min(1.0, age / 0.08) * Math.pow(1 - t, 0.9) * op, rgb);
                }
                case RIPPLE -> {
                    for (int w = 0; w < 3; w++) {
                        double aw = (age - w * 0.18 * life) / (life * 0.65);   // each wave starts a little later
                        if (aw < 0 || aw > 1) continue;
                        double e = 1 - Math.pow(1 - aw, 2);
                        double a = Math.min(1.0, aw / 0.08) * Math.pow(1 - aw, 1.4) * (1 - 0.2 * w);
                        ring(ctx, ci, r * (0.2 + 0.8 * e), 0, a * op, rgb);
                    }
                }
                default -> {                                         // RISE
                    for (int j = 0; j < 4; j++) {
                        double tj = t * 1.3 - j * 0.10;
                        if (tj < 0 || tj > 1) continue;
                        double a = Math.min(1.0, tj * 8) * Math.pow(1 - tj, 1.2) * (1 - 0.15 * j);
                        ring(ctx, ci, r * (0.95 - 0.30 * tj), tj * 1.8, a * op, rgb);
                    }
                }
            }
        }
    }

    /**
     * One ring lying flat at height dy above the circle's centre. ringRadius is the ring's outer edge in blocks.
     * The ground square around it is cut into horizontal strips (perpendicular to the camera's view direction, so
     * they stay horizontal on screen); strip k takes texture rows k..k+1.
     */
    private void ring(DrawContext ctx, Circle ci, double ringRadius, double dy, double alpha, int rgb) {
        int a = (int) Math.round(Math.max(0, Math.min(1, alpha)) * 255);
        if (a < 4 || ringRadius < 0.05) return;
        int color = (a << 24) | rgb;
        double s = ringRadius / OUTER;                                // half-size of the textured square
        int n = (int) quality.get();
        double rx = proj.rightX(), rz = proj.rightZ();
        double fx = rz, fz = -rx;                                     // ground forward = right rotated 90 degrees

        double[] xl = new double[n + 1], xr = new double[n + 1], y = new double[n + 1];
        boolean[] ok = new boolean[n + 1];
        for (int k = 0; k <= n; k++) {
            double zeta = -s + 2 * s * k / n;                         // far side has the larger zeta
            double bx = ci.x() + fx * zeta, bz = ci.z() + fz * zeta, by = ci.y() + dy;
            if (!proj.project(new Vec3d(bx - rx * s, by, bz - rz * s))) continue;
            double lx = proj.out[0], ly = proj.out[1];
            if (!proj.project(new Vec3d(bx + rx * s, by, bz + rz * s))) continue;
            xl[k] = lx;
            xr[k] = proj.out[0];
            y[k] = (ly + proj.out[1]) / 2.0;
            ok[k] = true;
        }
        for (int k = 0; k < n; k++) {
            if (!ok[k] || !ok[k + 1]) continue;                       // a strip behind the camera is dropped
            int y0 = (int) Math.round(Math.min(y[k], y[k + 1]));
            int y1 = (int) Math.round(Math.max(y[k], y[k + 1]));
            int x0 = (int) Math.round((xl[k] + xl[k + 1]) / 2.0);
            int x1 = (int) Math.round((xr[k] + xr[k + 1]) / 2.0);
            int w = x1 - x0, h = Math.max(1, y1 - y0);
            if (w < 1 || w > 4000 || h > 400) continue;
            int vTop = (n - (k + 1)) * TEX / n, vBot = (n - k) * TEX / n;   // far strips use the top of the texture
            ctx.drawTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, x0, y0, 0f, (float) vTop,
                    w, h, TEX, Math.max(1, vBot - vTop), TEX, TEX, color);
        }
    }
}
