package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Teleport aura: goes to the target (10-50 blocks away), hits it and goes back.
 * Position packets are sent in steps of at most STEP blocks.
 * Through walls = off: needs a collision-free straight line. On: the line is not checked
 * (the server still decides whether it accepts the movement).
 * Visible = on: you really stand at the target for one tick before returning, so the teleport is seen.
 * Visible = off: everything happens server-side within one tick, your screen does not move.
 * VodkaCraft bypass: shorter randomized hops, ground flag taken from the world instead of a constant,
 * a look packet toward the target before the hit and full weapon cooldown. These are heuristics; they have
 * not been checked against VodkaCraft's anti-cheat.
 */
public class TpAuraModule extends Module {
    /** Max distance per movement packet; vanilla rejects roughly >10 blocks in one packet. */
    private static final double STEP = 8.0;
    /** Hop length range in VodkaCraft bypass mode. */
    private static final double BYPASS_MIN = 2.5, BYPASS_MAX = 3.9;
    private static final double REACH = 3.0;
    private static final int MAX_CANDIDATES = 5;

    public final NumberSetting range = add(new NumberSetting("Range", 30, 10, 50, 1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting visible = add(new BoolSetting("Visible", true));
    public final BoolSetting throughWalls = add(new BoolSetting("Through walls", false));
    public final BoolSetting vodkaBypass = add(new BoolSetting("VodkaCraft bypass", false));

    /** Set while we stand at the target and still owe the return trip (visible mode). */
    private Vec3d returnTo;

    public TpAuraModule() { super("TPAura", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (returnTo != null) {          // phase 2: go back
            finishReturn(c, p);
            return;
        }
        boolean bypass = vodkaBypass.get();
        if (p.getAttackCooldownProgress(0.5f) < (bypass ? 1.0f : 0.95f)) return;

        List<LivingEntity> candidates = new ArrayList<>();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            if (p.distanceTo(le) <= range.get()) candidates.add(le);
        }
        candidates.sort(Comparator.comparingDouble(p::distanceTo));

        Vec3d start = Util.pos(p);
        int tried = 0;
        for (LivingEntity target : candidates) {
            if (tried++ >= MAX_CANDIDATES) break;
            if (p.distanceTo(target) <= REACH) {
                hit(c, p, target, start, bypass);
                return;
            }
            Vec3d goal = Util.pos(target);
            List<Vec3d> there = path(start, goal, bypass);
            if (!throughWalls.get() && !isClear(c, p, there)) continue;

            for (Vec3d v : there) send(p, v, bypass && groundAt(c, p, v));
            hit(c, p, target, goal, bypass);

            if (visible.get()) {
                p.setPosition(goal.x, goal.y, goal.z);   // stay here for one tick, return next tick
                returnTo = start;
            } else {
                sendBack(c, p, goal, start, bypass);
            }
            return;
        }
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        ClientPlayerEntity p = c.player;
        if (p != null && returnTo != null) finishReturn(c, p);
        returnTo = null;
    }

    private void finishReturn(MinecraftClient c, ClientPlayerEntity p) {
        Vec3d goal = Util.pos(p);
        Vec3d back = returnTo;
        returnTo = null;
        sendBack(c, p, goal, back, vodkaBypass.get());
        p.setPosition(back.x, back.y, back.z);
    }

    private static void sendBack(MinecraftClient c, ClientPlayerEntity p, Vec3d from, Vec3d to, boolean bypass) {
        List<Vec3d> back = path(from, to, bypass);
        for (int i = 0; i < back.size(); i++) {
            boolean ground = bypass ? groundAt(c, p, back.get(i)) : i == back.size() - 1 && p.isOnGround();
            send(p, back.get(i), ground);
        }
    }

    /** Attacks from {@code at} (the position the server currently has for us). Bypass: looks at the target first. */
    private static void hit(MinecraftClient c, ClientPlayerEntity p, LivingEntity target, Vec3d at, boolean bypass) {
        if (bypass) {
            Vec3d eye = at.add(0, p.getEyeHeight(p.getPose()), 0);
            float[] rot = Util.rotationsTo(eye, target.getBoundingBox().getCenter());
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(rot[0], rot[1], p.isOnGround(), p.horizontalCollision));
        }
        c.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        if (bypass) {   // the server keeps the aim until told otherwise; give the real view back
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                    p.getYaw(), MathHelper.clamp(p.getPitch(), -90f, 90f), p.isOnGround(), p.horizontalCollision));
        }
    }

    /** Points from (excluded) to to (included), at most STEP apart (bypass: random hops of BYPASS_MIN..BYPASS_MAX). */
    private static List<Vec3d> path(Vec3d from, Vec3d to, boolean bypass) {
        double total = from.distanceTo(to);
        List<Vec3d> points = new ArrayList<>();
        if (!bypass) {
            int n = Math.max(1, (int) Math.ceil(total / STEP));
            for (int i = 1; i <= n; i++) points.add(from.lerp(to, (double) i / n));
            return points;
        }
        if (total < 1.0E-6) { points.add(to); return points; }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double d = 0;
        while (d < total) {
            d = Math.min(total, d + r.nextDouble(BYPASS_MIN, BYPASS_MAX));
            points.add(from.lerp(to, d / total));
        }
        return points;
    }

    private static boolean isClear(MinecraftClient c, ClientPlayerEntity p, List<Vec3d> points) {
        for (Vec3d v : points) {
            if (!c.world.isSpaceEmpty(p.getBoundingBox().offset(v.x - p.getX(), v.y - p.getY(), v.z - p.getZ()))) {
                return false;
            }
        }
        return true;
    }

    /** True when the player's box at v is free and has a block right below it. */
    private static boolean groundAt(MinecraftClient c, ClientPlayerEntity p, Vec3d v) {
        Box box = p.getBoundingBox().offset(v.x - p.getX(), v.y - p.getY(), v.z - p.getZ());
        return c.world.isSpaceEmpty(box) && !c.world.isSpaceEmpty(box.offset(0, -0.05, 0));
    }

    private static void send(ClientPlayerEntity p, Vec3d v, boolean onGround) {
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(v.x, v.y, v.z, onGround, false));
    }
}
