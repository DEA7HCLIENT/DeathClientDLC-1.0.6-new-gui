package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Aim helpers shared by the rotation profiles: aim-point picking and a look-ray vs hitbox test. */
final class Rotations {
    private Rotations() {}

    /**
     * True if a ray from the eyes along (yaw, pitch) reaches the hitbox (grown by margin) within reach.
     * This is the same test the server's hit validation boils down to, so it is the honest "aligned" check.
     */
    static boolean rayHits(Vec3d eye, float yaw, float pitch, Box box, double reach, double margin) {
        Box b = margin == 0 ? box : box.expand(margin);
        if (b.contains(eye)) return true;
        Vec3d end = eye.add(Vec3d.fromPolar(pitch, yaw).multiply(reach));
        return b.raycast(eye, end).isPresent();
    }

    /**
     * The point inside the hitbox (inset a little from its edges) that is closest to where the view
     * already points. Aiming at it needs the smallest possible turn, and when the crosshair is already
     * on the target the turn is zero.
     */
    static Vec3d nearestPoint(Vec3d eye, float yaw, float pitch, Box box) {
        double ix = Math.min(0.12, box.getLengthX() * 0.25);
        double iy = Math.min(0.10, box.getLengthY() * 0.15);
        double iz = Math.min(0.12, box.getLengthZ() * 0.25);
        Vec3d on = eye.add(Vec3d.fromPolar(pitch, yaw).multiply(eye.distanceTo(box.getCenter())));
        return new Vec3d(
                MathHelper.clamp(on.x, box.minX + ix, box.maxX - ix),
                MathHelper.clamp(on.y, box.minY + iy, box.maxY - iy),
                MathHelper.clamp(on.z, box.minZ + iz, box.maxZ - iz));
    }

    /** Smallest rotation the mouse can produce at the current sensitivity (degrees per mouse count). */
    static float gcd(MinecraftClient c) {
        double f = c.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }

    /** Rounds a rotation delta to a whole number of mouse counts. */
    static float snap(float delta, float gcd) {
        return Math.round(delta / gcd) * gcd;
    }
}
