package dev.deathclient.dlc;

/** Accent color schemes for the ClickGUI, the main menu and the HUD. */
public enum Theme {
    CRIMSON("Crimson", 0xFFB3202A, 0xFF4A0D12),
    CYAN("Cyan", 0xFF1FA8C9, 0xFF0C4452),
    VIOLET("Violet", 0xFF8A4FD6, 0xFF3A1F5C),
    EMERALD("Emerald", 0xFF2FA86B, 0xFF12452C),
    MONO("Mono", 0xFF8A8A8A, 0xFF3A3A3A),
    SUNSET("Sunset", 0xFFE8743B, 0xFF5A2410),
    OCEAN("Ocean", 0xFF2F6FDB, 0xFF132F5E),
    ROSE("Rose", 0xFFD9487D, 0xFF551B33),
    GOLD("Gold", 0xFFD4A21F, 0xFF4F3C08),
    ICE("Ice", 0xFF7FC7E8, 0xFF2A4A5A),
    LIME("Lime", 0xFF8BC34A, 0xFF33471C),
    // Two- and three-colour themes (appended: saved configs store the theme by index).
    AURORA("Aurora", new int[]{0xFF2FA86B, 0xFF1FA8C9, 0xFF8A4FD6}),
    FLAME("Flame", new int[]{0xFFB3202A, 0xFFE8743B, 0xFFD4A21F}),
    DUSK("Dusk", new int[]{0xFF2F6FDB, 0xFF8A4FD6, 0xFFD9487D}),
    CANDY("Candy", new int[]{0xFFD9487D, 0xFF8A4FD6}),
    LAGOON("Lagoon", new int[]{0xFF2F6FDB, 0xFF2FD6B0});

    public final String label;
    private final int accent, dim;
    /** 1 colour = plain theme; 2 or 3 colours = gradient theme. */
    private final int[] stops;

    Theme(String label, int accent, int dim) {
        this.label = label;
        this.accent = accent;
        this.dim = dim;
        this.stops = new int[]{accent};
    }

    Theme(String label, int[] stops) {
        this.label = label;
        this.accent = stops[0];
        this.dim = mix(stops[0], 0xFF000000, 0.6f);
        this.stops = stops;
    }

    private static int index = 0;

    public static Theme current() { return values()[index]; }

    public static void set(Theme t) { index = t.ordinal(); }

    public static void set(int i) { index = ((i % values().length) + values().length) % values().length; }

    public static void cycle() { set(index + 1); }

    /**
     * The theme colour. For a gradient theme it drifts slowly through all its colours, so everything that
     * uses accent() (HUD, ESP, menus) shows the whole palette over time.
     */
    public int accent() {
        if (stops.length == 1) return accent;
        double ph = (System.currentTimeMillis() % 8000L) / 8000.0;               // 0..1 loop
        return at((float) (0.5 - 0.5 * Math.cos(ph * 2 * Math.PI)));            // smooth there-and-back
    }

    public int dim() { return stops.length == 1 ? dim : mix(accent(), 0xFF000000, 0.6f); }

    /** True for the two- and three-colour themes. */
    public boolean gradient() { return stops.length > 1; }

    /** Colour at position t (0..1) along the gradient; for a plain theme always its single colour. */
    public int at(float t) {
        if (stops.length == 1) return stops[0];
        t = Math.max(0f, Math.min(1f, t)) * (stops.length - 1);
        int i = Math.min((int) t, stops.length - 2);
        return mix(stops[i], stops[i + 1], t - i);
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
    public int index() { return ordinal(); }
}
