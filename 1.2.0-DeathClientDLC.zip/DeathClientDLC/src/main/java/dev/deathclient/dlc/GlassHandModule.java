package dev.deathclient.dlc;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.DyedColorComponent;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Arm;
import java.awt.Color;

/**
 * Glass Hand: a soft glass-like glow around the first-person hand or the item in it, drawn over the HUD.
 * Colour modes: Auto (the colour of the held item, or a skin tone for an empty hand), Theme, Custom, Rainbow.
 * It follows the hand when View Model moves it.
 * Auto picks the colour from the item type (block map colour, dye, potion, material in the item's name, else a
 * stable colour from its id), not from the exact texture pixels.
 */
public class GlassHandModule extends Module {
    private static final int SKIN = 0xC9967A;

    public final NumberSetting color = add(new NumberSetting("Color", 1, 1, 4, 1).labels("Auto", "Theme", "Custom", "Rainbow"));
    public final NumberSetting red = add(new NumberSetting("Red", 120, 0, 255, 1));
    public final NumberSetting green = add(new NumberSetting("Green", 190, 0, 255, 1));
    public final NumberSetting blue = add(new NumberSetting("Blue", 255, 0, 255, 1));
    /** Glow size in GUI pixels. */
    public final NumberSetting radius = add(new NumberSetting("Radius", 70, 20, 160, 5));
    public final NumberSetting intensity = add(new NumberSetting("Intensity", 45, 5, 100, 5));
    public final BoolSetting glass = add(new BoolSetting("Glass shine", true));
    public final BoolSetting pulse = add(new BoolSetting("Pulse", true));
    public final BoolSetting offhand = add(new BoolSetting("Off hand", false));
    public final BoolSetting emptyHand = add(new BoolSetting("Empty hand", true));

    public GlassHandModule() { super("Glass Hand", Category.VISUALS); }

    static void render(DrawContext ctx, RenderTickCounter tick) {
        GlassHandModule m = ModuleManager.get(GlassHandModule.class);
        MinecraftClient c = MinecraftClient.getInstance();
        if (m == null || !m.isEnabled() || c.player == null || c.currentScreen != null) return;
        if (c.options.hudHidden || Hud.hidden || !c.options.getPerspective().isFirstPerson()) return;

        boolean mainRight = c.options.getMainArm().getValue() == Arm.RIGHT;
        m.drawHand(ctx, c, true, mainRight, c.player.getMainHandStack());
        if (m.offhand.get()) m.drawHand(ctx, c, false, mainRight, c.player.getOffHandStack());
    }

    private void drawHand(DrawContext ctx, MinecraftClient c, boolean main, boolean mainRight, ItemStack stack) {
        if (stack.isEmpty() && (!emptyHand.get() || !main)) return;   // an empty off hand is not drawn by the game
        boolean right = main == mainRight;
        ViewModelModule vm = ModuleManager.get(ViewModelModule.class);
        double k = ViewModelModule.unit(c);
        double dx = 0, dy = 0;
        if (vm != null && vm.isEnabled()) {
            dx = (main ? vm.mainX : vm.offX).get() * k;
            dy = -(main ? vm.mainY : vm.offY).get() * k;
        }
        int cx = (int) (ViewModelModule.baseX(c, right) + dx), cy = (int) (ViewModelModule.baseY(c) + dy);

        double pulseK = pulse.get() ? 0.85 + 0.15 * Math.sin(System.currentTimeMillis() / 350.0) : 1.0;
        float alpha = (float) (intensity.get() / 100.0 * 0.5 * pulseK);          // total opacity at the centre
        glow(ctx, cx, cy, (int) radius.get(), pick(stack), alpha, glass.get());
    }

    /** Radial glow from stacked ellipses; with the glass option the core is lightened like a lit glass pane. */
    private static void glow(DrawContext ctx, int cx, int cy, int r, int rgb, float alpha, boolean glass) {
        final int layers = 10;
        for (int i = 0; i < layers; i++) {
            float f = i / (float) (layers - 1);
            int rx = Math.max(2, (int) (r * (1f - f * 0.88f)));
            int ry = Math.max(2, (int) (rx * 1.2f));
            int col = rgb;
            if (glass && f > 0.6f) col = mix(rgb, 0xFFFFFF, (f - 0.6f) / 0.4f * 0.45f);
            int a = Math.min(255, Math.max(1, (int) (alpha / layers * 255f * 1.9f)));
            int argb = (a << 24) | col;
            for (int y = -ry; y < ry; y += 2) {
                int half = (int) (rx * Math.sqrt(1.0 - (double) y * y / ((double) ry * ry)));
                if (half > 0) ctx.fill(cx - half, cy + y, cx + half, cy + y + 2, argb);
            }
        }
    }

    // ---- colour ----

    private int pick(ItemStack stack) {
        switch ((int) color.get()) {
            case 2: return Theme.current().accent() & 0xFFFFFF;
            case 3: return ((int) red.get() << 16) | ((int) green.get() << 8) | (int) blue.get();
            case 4: return Color.HSBtoRGB((System.currentTimeMillis() % 4000) / 4000f, 0.6f, 1f) & 0xFFFFFF;
            default: return stack.isEmpty() ? SKIN : itemColor(stack);
        }
    }

    private static int itemColor(ItemStack stack) {
        if (stack.contains(DataComponentTypes.DYED_COLOR)) return DyedColorComponent.getColor(stack, 0) & 0xFFFFFF;
        if (stack.getItem() instanceof BlockItem bi) {
            Block b = bi.getBlock();
            return b.getDefaultMapColor().color & 0xFFFFFF;
        }
        String id = Registries.ITEM.getId(stack.getItem()).getPath();
        for (String[] e : MATERIALS) {
            if (id.contains(e[0])) return Integer.parseInt(e[1], 16);
        }
        // stable colour from the id, so every other item still gets its own tint
        return Color.HSBtoRGB((id.hashCode() & 0x7FFFFFFF) % 360 / 360f, 0.55f, 1f) & 0xFFFFFF;
    }

    /** Material word in the item id -> colour. First match wins. */
    private static final String[][] MATERIALS = {
            {"netherite", "7A6A8A"}, {"diamond", "33EBCB"}, {"golden", "FFD83A"}, {"gold", "FFD83A"},
            {"iron", "D8D8D8"}, {"copper", "E07B50"}, {"emerald", "17DD62"}, {"lapis", "345EC3"},
            {"amethyst", "9A5CC6"}, {"redstone", "E02020"}, {"quartz", "EDE6DC"}, {"chainmail", "9AA0A8"},
            {"stone", "8A8A8A"}, {"wooden", "A9814D"}, {"leather", "9A5B3A"}, {"turtle", "3E9A4A"},
            {"bow", "B08850"}, {"arrow", "B0B0B0"}, {"shield", "A9814D"}, {"trident", "3FB8A8"},
            {"totem", "F2D338"}, {"ender", "2BBFA0"}, {"tnt", "DB2F2F"}, {"blaze", "FFA800"},
            {"fire", "FF8A1F"}, {"lava", "FF6A00"}, {"water", "3F76E4"}, {"slime", "7EBF6E"},
            {"nether_star", "F4F4FF"}, {"apple", "E23C3C"}, {"carrot", "ED9121"}, {"bread", "C98F4A"},
            {"potion", "6A5ACD"}, {"pearl", "2BBFA0"}, {"crystal", "E26AE8"}, {"anchor", "7A4AD6"},
    };

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = (int) (((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = (int) ((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return (r << 16) | (g << 8) | bl;
    }
}
