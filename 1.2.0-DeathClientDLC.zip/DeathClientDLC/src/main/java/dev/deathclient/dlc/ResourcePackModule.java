package dev.deathclient.dlc;

/**
 * Resource Pack: blocks resource packs that a server tries to send. Nothing is downloaded or loaded, so your own
 * packs stay as they are and joining is not held up by a big download. The work is done in
 * ClientCommonNetworkHandlerMixin; this class only holds the switch and the setting.
 */
public class ResourcePackModule extends Module {
    /**
     * On: tell the server "accepted, downloaded, loaded" for a pack that was never loaded, so servers that demand
     * their pack do not kick you. Off: answer "declined" (some servers kick for that).
     */
    public final BoolSetting reportLoaded = add(new BoolSetting("Report as loaded", true));

    public ResourcePackModule() { super("Resource Pack", Category.MISC); }
}
