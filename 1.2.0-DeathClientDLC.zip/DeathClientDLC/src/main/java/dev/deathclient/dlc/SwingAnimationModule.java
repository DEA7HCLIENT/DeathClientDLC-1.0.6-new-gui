package dev.deathclient.dlc;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/**
 * Swing animation of the first-person hand. Duration overrides the swing length (see LivingEntityMixin).
 * Mode: Default (vanilla), Swipe (the hand sweeps sideways across the screen), Down (the hand drops down and
 * forward) or Custom (your own offsets and angles, reached at the middle of the swing). The modes replace
 * vanilla's swing offset for held items (HeldItemRendererMixin); an empty hand keeps the vanilla swing.
 */
public class SwingAnimationModule extends Module {
    private static final int SWIPE = 2, DOWN = 3, CUSTOM = 4;

    public final NumberSetting mode = add(new NumberSetting("Mode", 1, 1, 4, 1).labels("Default", "Swipe", "Down", "Custom"));
    public final NumberSetting duration = add(new NumberSetting("Duration", 6, 1, 20, 1));
    /** Custom mode: how far the hand moves (units) and turns (degrees) at the peak of the swing. */
    public final NumberSetting posX = add(new NumberSetting("Pos X", 0, -1, 1, 0.05));
    public final NumberSetting posY = add(new NumberSetting("Pos Y", -0.2, -1, 1, 0.05));
    public final NumberSetting posZ = add(new NumberSetting("Pos Z", -0.2, -1, 1, 0.05));
    public final NumberSetting rotX = add(new NumberSetting("Rot X", -40, -90, 90, 5));
    public final NumberSetting rotY = add(new NumberSetting("Rot Y", 0, -90, 90, 5));
    public final NumberSetting rotZ = add(new NumberSetting("Rot Z", 0, -90, 90, 5));

    public SwingAnimationModule() { super("Swing Animation", Category.RENDER); }

    public int duration() { return (int) duration.get(); }

    /** Applies the chosen swing to the matrix. Returns true if it replaced vanilla's swing offset. */
    public static boolean apply(MatrixStack m, Arm arm, float progress) {
        SwingAnimationModule s = ModuleManager.get(SwingAnimationModule.class);
        if (s == null || !s.isEnabled()) return false;
        int mode = (int) s.mode.get();
        if (mode < SWIPE) return false;
        float side = arm == Arm.RIGHT ? 1f : -1f;                 // mirror for the left hand
        float g = MathHelper.sin(MathHelper.sqrt(progress) * (float) Math.PI);   // 0 -> 1 -> 0 over the swing
        // Vanilla translates the hand by (side * -0.4 * g, 0.2 * sin(2 * sqrt(p) * PI), -0.2 * sin(p * PI)) BEFORE it
        // calls applySwingOffset, so cancelling only that method leaves the vanilla motion stacked under ours.
        // Equip offset is a pure translation, so undoing the vanilla part here is exact.
        float sq = MathHelper.sqrt(progress);
        m.translate(side * 0.4f * g,
                -0.2f * MathHelper.sin(sq * (float) Math.PI * 2f),
                0.2f * MathHelper.sin(progress * (float) Math.PI));
        switch (mode) {
            case SWIPE -> {
                m.translate(side * -0.45f * g, -0.05f * g, -0.1f * g);
                rotate(m, RotationAxis.POSITIVE_Y, side * 50f * g);
                rotate(m, RotationAxis.POSITIVE_Z, side * -30f * g);
            }
            case DOWN -> {
                m.translate(0f, -0.35f * g, -0.15f * g);
                rotate(m, RotationAxis.POSITIVE_X, -35f * g);
            }
            default -> {
                m.translate(side * (float) s.posX.get() * g, (float) s.posY.get() * g, (float) s.posZ.get() * g);
                rotate(m, RotationAxis.POSITIVE_X, (float) s.rotX.get() * g);
                rotate(m, RotationAxis.POSITIVE_Y, side * (float) s.rotY.get() * g);
                rotate(m, RotationAxis.POSITIVE_Z, side * (float) s.rotZ.get() * g);
            }
        }
        return true;
    }

    private static void rotate(MatrixStack m, RotationAxis axis, float degrees) {
        m.multiply(axis.rotationDegrees(degrees));
    }
}
