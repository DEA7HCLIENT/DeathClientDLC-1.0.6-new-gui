package dev.deathclient.dlc;

/** HUD toggle: the top status pill (clock, client name, theme, config) and the active-effects row. */
public class DynamicIslandModule extends Module {
    public final BoolSetting showClock = add(new BoolSetting("Clock", true));
    public final BoolSetting showEffects = add(new BoolSetting("Effects", true));
    public final BoolSetting showConfig = add(new BoolSetting("Config name", true));
    /** Offsets set by dragging in the open chat (island: from top-center, list: from top-right). */
    public final NumberSetting islandX = add(new NumberSetting("Island X", 0, -1000, 1000, 1));
    public final NumberSetting islandY = add(new NumberSetting("Island Y", 0, -1000, 1000, 1));
    public final NumberSetting listX = add(new NumberSetting("List X", 0, -1000, 1000, 1));
    public final NumberSetting listY = add(new NumberSetting("List Y", 0, -1000, 1000, 1));

    public DynamicIslandModule() { super("Dynamic Island", Category.MISC, true); }
}
