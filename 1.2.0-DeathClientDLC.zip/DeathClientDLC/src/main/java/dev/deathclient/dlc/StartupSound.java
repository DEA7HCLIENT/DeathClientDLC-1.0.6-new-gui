package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Plays assets/deathclientdlc/sounds/startup.ogg once per launch, when the title screen first appears. */
final class StartupSound {
    private static boolean played;

    private StartupSound() {}

    static void play(MinecraftClient c) {
        if (played) return;
        played = true;
        try {
            // Not registered anywhere: the sound system finds it through sounds.json by id.
            SoundEvent e = SoundEvent.of(Identifier.of("deathclientdlc", "startup"));
            c.getSoundManager().play(PositionedSoundInstance.ui(e, 1.0f, 1.0f));
        } catch (Throwable ignored) {
            // a missing sound must never stop the game from starting
        }
    }
}
