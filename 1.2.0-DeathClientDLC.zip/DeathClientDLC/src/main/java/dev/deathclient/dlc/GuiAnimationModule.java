package dev.deathclient.dlc;

/**
 * Open / close animation of the ClickGUI window. Mode: slide from Bottom, Top, Left or Right, Pop (springs out
 * with a small overshoot), Bounce (a bubbly elastic "blob" pop) or Fade. Closing plays the same animation backwards.
 * Turn the module off to have no animation at all.
 */
public class GuiAnimationModule extends Module {
    private static final int BOTTOM = 1, TOP = 2, LEFT = 3, RIGHT = 4, POP = 5, BOUNCE = 6, FADE = 7;

    public final NumberSetting mode = add(new NumberSetting("Mode", 1, 1, 7, 1)
            .labels("Bottom", "Top", "Left", "Right", "Pop", "Bounce", "Fade"));
    /** Length of the animation in milliseconds. */
    public final NumberSetting duration = add(new NumberSetting("Duration", 300, 100, 800, 25));
    /** Play the animation backwards when the GUI closes. */
    public final BoolSetting closeAnimation = add(new BoolSetting("Close animation", true));

    public GuiAnimationModule() { super("GUI Animation", Category.MISC, true); }

    public double durationMs() { return duration.get(); }

    /** Where the window is at animation progress p (0 = hidden, 1 = fully shown). */
    record Pose(double dx, double dy, double scale, double alpha) {}

    Pose pose(double p, int winX, int winY, int ww, int wh, int screenW, int screenH) {
        p = Math.max(0, Math.min(1, p));
        switch ((int) mode.get()) {
            case TOP:    return new Pose(0, -(1 - outCubic(p)) * (winY + wh), 1, 1);
            case LEFT:   return new Pose(-(1 - outCubic(p)) * (winX + ww), 0, 1, 1);
            case RIGHT:  return new Pose((1 - outCubic(p)) * (screenW - winX), 0, 1, 1);
            case POP:    return new Pose(0, 0, Math.max(0, outBack(p)), Math.min(1, p * 2.5));
            case BOUNCE: return new Pose(0, 0, Math.max(0, outElastic(p)), Math.min(1, p * 3.0));
            case FADE: {
                double s = p * p * (3 - 2 * p);                      // smoothstep
                return new Pose(0, 0, 0.94 + 0.06 * s, s);
            }
            default:     return new Pose(0, (1 - outCubic(p)) * (screenH - winY), 1, 1);   // BOTTOM
        }
    }

    private static double outCubic(double t) { return 1 - Math.pow(1 - t, 3); }

    private static double outBack(double t) {
        double c1 = 1.70158, c3 = c1 + 1;
        return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
    }

    private static double outElastic(double t) {
        if (t <= 0) return 0;
        if (t >= 1) return 1;
        return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI / 3)) + 1;
    }
}
