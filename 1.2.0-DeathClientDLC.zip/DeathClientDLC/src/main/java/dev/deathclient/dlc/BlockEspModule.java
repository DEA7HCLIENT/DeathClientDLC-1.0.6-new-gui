package dev.deathclient.dlc;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

/**
 * Block ESP: 3D wireframe cubes around chosen blocks (ores, chests, spawners...) visible through walls.
 * Each of the 12 edges of the block is projected to the screen with perspective (edges behind the camera
 * are cut off first) and drawn as a line, so the box really looks like a cube in the world, not a flat
 * rectangle. Same overlay technique as the Target ESP modules, so it needs no world-render hook.
 * The world is rescanned every few ticks.
 */
public class BlockEspModule extends Module {
    private record Group(BoolSetting setting, Block[] blocks, int color) {}

    public final NumberSetting range = add(new NumberSetting("Range", 16, 4, 32, 2));
    public final NumberSetting maxBoxes = add(new NumberSetting("Max boxes", 200, 20, 600, 20));
    /** Far boxes are drawn fainter. */
    public final BoolSetting fade = add(new BoolSetting("Distance fade", true));

    private final List<Group> groups = new ArrayList<>();

    private record Hit(BlockPos pos, int color) {}
    private volatile List<Hit> hits = List.of();
    private int ticks;

    public BlockEspModule() {
        super("Block ESP", Category.RENDER);
        group("Diamond", true, 0x33E6FF, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE);
        group("Emerald", true, 0x2EE05A, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE);
        group("Gold", true, 0xFFD42A, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.NETHER_GOLD_ORE);
        group("Iron", false, 0xD8B59A, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE);
        group("Coal", false, 0x777777, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE);
        group("Redstone", false, 0xFF3030, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE);
        group("Lapis", false, 0x3050FF, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE);
        group("Copper", false, 0xE0803A, Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE);
        group("Ancient Debris", true, 0xA0522D, Blocks.ANCIENT_DEBRIS);
        group("Quartz", false, 0xEEEEEE, Blocks.NETHER_QUARTZ_ORE);
        group("Spawner", true, 0xB040FF, Blocks.SPAWNER);
        group("Chests", true, 0xFFA020, Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL);
        group("Ender Chest", false, 0xA050FF, Blocks.ENDER_CHEST);
    }

    private void group(String name, boolean on, int color, Block... blocks) {
        groups.add(new Group(add(new BoolSetting(name, on)), blocks, color));
    }

    @Override
    protected void onEnable() { ticks = 0; hits = List.of(); }

    @Override
    protected void onDisable() { hits = List.of(); }

    @Override
    public void onTick(MinecraftClient c) {
        if (ticks++ % 10 != 0) return;
        scan(c);
    }

    private void scan(MinecraftClient c) {
        var w = c.world;
        BlockPos center = c.player.getBlockPos();
        int r = (int) range.get();
        int bottom = w.getBottomY(), top = bottom + w.getHeight() - 1;
        int y0 = Math.max(bottom, center.getY() - r), y1 = Math.min(top, center.getY() + r);
        int cap = (int) maxBoxes.get();

        List<Group> active = new ArrayList<>();
        for (Group g : groups) if (g.setting().get()) active.add(g);
        if (active.isEmpty()) { hits = List.of(); return; }

        List<Hit> found = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = center.getX() - r; x <= center.getX() + r; x++) {
            for (int z = center.getZ() - r; z <= center.getZ() + r; z++) {
                for (int y = y0; y <= y1; y++) {
                    m.set(x, y, z);
                    var state = w.getBlockState(m);
                    if (state.isAir()) continue;
                    for (Group g : active) {
                        boolean match = false;
                        for (Block b : g.blocks()) if (state.isOf(b)) { match = true; break; }
                        if (match) { found.add(new Hit(m.toImmutable(), g.color())); break; }
                    }
                }
            }
        }
        // Keep the nearest ones if there are too many.
        if (found.size() > cap) {
            found.sort((a, b) -> Double.compare(center.getSquaredDistance(a.pos()), center.getSquaredDistance(b.pos())));
            found = new ArrayList<>(found.subList(0, cap));
        }
        hits = found;
    }

    // ---- HUD overlay ----

    private static final ScreenProjector PROJ = new ScreenProjector();
    private static final double[] SEG = new double[4];

    /** HUD callback, see DeathClientDLC. */
    static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        FreecamModule.frame();   // keep the freecam rotation in sync every frame (cheap no-op otherwise)
        BlockEspModule m = ModuleManager.get(BlockEspModule.class);
        if (m == null || !m.isEnabled() || Hud.hidden) return;
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || c.options.hudHidden) return;
        List<Hit> list = m.hits;
        if (list.isEmpty()) return;

        PROJ.begin(c, tickCounter.getTickProgress(false));
        int sw = c.getWindow().getScaledWidth(), sh = c.getWindow().getScaledHeight();
        double maxDist = m.range.get() * 1.2;
        for (Hit h : list) {
            double bx = h.pos().getX(), by = h.pos().getY(), bz = h.pos().getZ();
            double depth = PROJ.depth(new Vec3d(bx + 0.5, by + 0.5, bz + 0.5));
            if (depth < -1.0) continue;                                   // whole block behind the camera
            int alpha = 255;
            if (m.fade.get()) alpha = (int) (255 * Math.max(0.35, Math.min(1.0, 1.0 - 0.6 * depth / maxDist)));
            int col = (alpha << 24) | h.color();

            // 12 edges: corner i (bits x=1, y=2, z=4) to the corner with one more bit set.
            for (int i = 0; i < 8; i++) {
                for (int bit = 1; bit <= 4; bit <<= 1) {
                    if ((i & bit) != 0) continue;
                    int j = i | bit;
                    Vec3d a = new Vec3d(bx + (i & 1), by + ((i >> 1) & 1), bz + ((i >> 2) & 1));
                    Vec3d b = new Vec3d(bx + (j & 1), by + ((j >> 1) & 1), bz + ((j >> 2) & 1));
                    if (!PROJ.segment(a, b, SEG)) continue;
                    line(ctx, SEG[0], SEG[1], SEG[2], SEG[3], col, sw, sh);
                }
            }
        }
    }

    /** One pixel wide line between two GUI points: a thin rectangle rotated onto the line. */
    private static void line(DrawContext ctx, double x1, double y1, double x2, double y2, int col, int sw, int sh) {
        if ((x1 < 0 && x2 < 0) || (x1 > sw && x2 > sw) || (y1 < 0 && y2 < 0) || (y1 > sh && y2 > sh)) return;   // off screen
        double dx = x2 - x1, dy = y2 - y1;
        double len = Math.sqrt(dx * dx + dy * dy);
        if (len < 0.5 || len > 4000) return;
        var mt = ctx.getMatrices();
        mt.pushMatrix();
        mt.translate((float) x1, (float) y1);
        mt.rotate((float) Math.atan2(dy, dx));
        ctx.fill(0, 0, (int) Math.ceil(len), 1, col);
        mt.popMatrix();
    }
}
