package dev.deathclient.dlc;

import net.minecraft.client.gui.screen.Screen;

/**
 * GUI Style: which ClickGUI is opened. Classic = the single window with the sidebar and module cards,
 * Panels = a separate draggable window per category, CS = a Counter-Strike cheat-menu look (flat dark window,
 * tab column on the left, check boxes and sliders). Changing it while the menu is open switches it at once.
 */
public class GuiStyleModule extends Module {
    public static final int CLASSIC = 1, PANELS = 2, CS = 3;

    public final NumberSetting style = add(new NumberSetting("Style", CLASSIC, 1, 3, 1).labels("Classic", "Panels", "CS"));

    public GuiStyleModule() { super("GUI Style", Category.MISC, true); }

    /** The selected style (Classic when the module is missing). */
    public static int style() {
        GuiStyleModule m = ModuleManager.get(GuiStyleModule.class);
        return m == null ? CLASSIC : (int) m.style.get();
    }

    /** A new ClickGUI screen of the selected style. */
    public static Screen create() {
        return switch (style()) {
            case PANELS -> new PanelGuiScreen();
            case CS -> new CsGuiScreen();
            default -> new ClickGuiScreen();
        };
    }

    /** True for any of the ClickGUI screens. */
    public static boolean isClickGui(Screen s) {
        return s instanceof ClickGuiScreen || s instanceof PanelGuiScreen || s instanceof CsGuiScreen;
    }
}
