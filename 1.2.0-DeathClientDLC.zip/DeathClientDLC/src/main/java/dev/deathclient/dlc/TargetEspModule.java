package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Rotating particle ring around the nearest target (the one KillAura / TPAura would pick). */
public class TargetEspModule extends Module {
    public final NumberSetting style = add(Fx.styleSetting());
    public final NumberSetting range = add(new NumberSetting("Range", 8, 3, 20, 1));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));

    public TargetEspModule() { super("Target ESP", Category.VISUALS); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        LivingEntity target = null;
        double best = range.get();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive() || le.isSpectator()) continue;
            if (playersOnly.get() && !(le instanceof PlayerEntity)) continue;
            if (Friends.skip(le)) continue;
            double d = p.distanceTo(le);
            if (d <= best) { best = d; target = le; }
        }
        if (target == null) return;

        var effect = Fx.style(style);
        double radius = target.getWidth() * 0.9 + 0.2;
        double y = target.getY() + (0.5 + 0.5 * Math.sin(p.age * 0.15)) * target.getHeight();
        for (int i = 0; i < 3; i++) {
            double a = p.age * 0.35 + i * (2 * Math.PI / 3);
            Fx.spawn(c, effect, target.getX() + Math.cos(a) * radius, y, target.getZ() + Math.sin(a) * radius);
        }
    }
}
