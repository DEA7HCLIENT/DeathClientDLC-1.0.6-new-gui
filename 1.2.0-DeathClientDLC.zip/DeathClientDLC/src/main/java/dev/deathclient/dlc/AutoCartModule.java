package dev.deathclient.dlc;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.SpectralArrowEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

/**
 * AutoCart: when you shoot an arrow, the module simulates its flight, finds the block it will hit and
 * places a rail on top of the floor next to that spot, then a TNT minecart on the rail.
 * <ul>
 *   <li>Rotation: Snap (sharp: one grid-quantized turn sent to the server for each placement, the camera
 *       never moves) or Smooth (the camera eases to the spot, the block is placed once it is aimed at).</li>
 *   <li>If the spot is out of Range the plan waits (up to ~6 s) for you to get closer.</li>
 *   <li>Needs a rail (any kind) and a TNT minecart on the hotbar.</li>
 * </ul>
 */
public class AutoCartModule extends Module {
    private static final int SNAP = 1, SMOOTH = 2;
    private static final int RAIL = 0, WAIT = 1, CART = 2;
    private static final Item[] RAILS = {Items.RAIL, Items.POWERED_RAIL, Items.DETECTOR_RAIL, Items.ACTIVATOR_RAIL};

    public final NumberSetting rotation = add(new NumberSetting("Rotation", 1, 1, 2, 1).labels("Snap", "Smooth"));
    /** Smooth: max degrees per tick. */
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 20, 4, 60, 1));
    public final NumberSetting range = add(new NumberSetting("Range", 4.5, 2, 6, 0.5));
    /** Ticks between the rail and the minecart. */
    public final NumberSetting delay = add(new NumberSetting("Delay", 1, 0, 10, 1));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));

    private final Set<Integer> seen = new HashSet<>();
    /** Planned rail position, or null when there is no plan. */
    private BlockPos railPos;
    private int stage, wait, life, tries;

    public AutoCartModule() { super("AutoCart", Category.COMBAT); }

    @Override
    protected void onDisable() { railPos = null; seen.clear(); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (railPos == null) {
            scan(c, p);
            if (railPos == null) return;
        }
        if (--life <= 0) { railPos = null; return; }
        if (c.currentScreen != null || p.isUsingItem()) return;   // drawing the bow again: wait

        if (stage == WAIT) {
            if (wait-- > 0) return;
            stage = CART;
        }
        step(c, p);
    }

    // ---- arrow tracking ----

    /** Looks for a freshly shot arrow of ours and plans the rail where it will land. */
    private void scan(MinecraftClient c, ClientPlayerEntity p) {
        if (seen.size() > 128) seen.clear();
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof ArrowEntity || e instanceof SpectralArrowEntity)) continue;
            PersistentProjectileEntity a = (PersistentProjectileEntity) e;
            if (a.getOwner() != p || a.age > 3 || !seen.add(a.getId())) continue;
            BlockPos spot = predict(c.world, a);
            if (spot == null) continue;
            railPos = spot;
            stage = RAIL;
            wait = 0;
            tries = 0;
            life = 120;
            return;
        }
    }

    /** Flies the arrow forward tick by tick (gravity, drag) until it meets a block; returns the rail spot. */
    private static BlockPos predict(World w, Entity a) {
        Vec3d pos = Util.pos(a), vel = a.getVelocity();
        for (int i = 0; i < 300; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult hit = w.raycast(new RaycastContext(pos, next,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, a));
            if (hit.getType() == HitResult.Type.BLOCK) return railSpot(w, hit);
            boolean water = !w.getFluidState(BlockPos.ofFloored(next.x, next.y, next.z)).isEmpty();
            vel = vel.multiply(water ? 0.6 : 0.99).subtract(0, 0.05, 0);
            pos = next;
            if (pos.y < w.getBottomY() - 8) return null;
        }
        return null;
    }

    /** The air cell next to the hit face, lowered (up to 4 blocks) until it stands on a solid floor. */
    private static BlockPos railSpot(World w, BlockHitResult hit) {
        BlockPos pos = hit.getBlockPos().offset(hit.getSide());
        for (int i = 0; i < 5; i++) {
            BlockPos below = pos.down();
            if (w.getBlockState(below).isSideSolidFullSquare(w, below, Direction.UP)) {
                BlockState st = w.getBlockState(pos);
                boolean free = st.isIn(BlockTags.RAILS)
                        || ((st.isAir() || st.isReplaceable()) && w.getFluidState(pos).isEmpty());
                return free ? pos : null;
            }
            pos = below;
        }
        return null;
    }

    // ---- placing ----

    private void step(MinecraftClient c, ClientPlayerEntity p) {
        BlockPos floor = railPos.down();
        int slot;
        BlockHitResult hit;
        Vec3d aim;
        if (stage == RAIL) {
            if (isRail(c, railPos)) { stage = WAIT; wait = (int) delay.get(); return; }   // already laid
            slot = railSlot(p);
            if (slot < 0) { fail(p, "AutoCart: нет рельс на хотбаре"); return; }
            aim = new Vec3d(floor.getX() + 0.5, floor.getY() + 1.0, floor.getZ() + 0.5);
            hit = new BlockHitResult(aim, Direction.UP, floor, false);
        } else {
            if (!isRail(c, railPos)) {                                  // the rail did not appear: lay it again
                if (++tries > 3) { fail(p, "AutoCart: не удалось поставить рельсу"); return; }
                stage = RAIL;
                return;
            }
            slot = Util.findHotbar(p, Items.TNT_MINECART);
            if (slot < 0) { fail(p, "AutoCart: нет вагонетки с TNT на хотбаре"); return; }
            aim = new Vec3d(railPos.getX() + 0.5, railPos.getY() + 0.125, railPos.getZ() + 0.5);
            hit = new BlockHitResult(aim, Direction.UP, railPos, false);
        }
        if (p.getEyePos().distanceTo(aim) > range.get()) return;        // too far: keep waiting for range

        boolean snapMode = (int) rotation.get() == SNAP;
        float[] want = Util.rotationsTo(p.getEyePos(), aim);
        if (snapMode) {
            float gcd = Rotations.gcd(c);
            float yaw = p.getYaw() + Rotations.snap(MathHelper.wrapDegrees(want[0] - p.getYaw()), gcd);
            float pitch = MathHelper.clamp(p.getPitch() + Rotations.snap(want[1] - p.getPitch(), gcd), -90f, 90f);
            sendLook(c, p, yaw, pitch);
        } else {
            turnToward(c, p, want);
            float ey = Math.abs(MathHelper.wrapDegrees(want[0] - p.getYaw()));
            float ep = Math.abs(want[1] - p.getPitch());
            if (ey > 4f || ep > 4f) return;                              // not aimed yet, keep turning
        }

        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        c.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        p.swingHand(Hand.MAIN_HAND);
        if (restoreSlot.get()) p.getInventory().setSelectedSlot(prev);
        if (snapMode) sendLook(c, p, p.getYaw(), p.getPitch());          // back to the real view

        if (stage == RAIL) { stage = WAIT; wait = (int) delay.get(); }
        else railPos = null;                                             // done
    }

    /** Eases the camera toward (yaw, pitch): fast when far, slow when close, on the mouse grid. */
    private void turnToward(MinecraftClient c, ClientPlayerEntity p, float[] want) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        float max = (float) turnSpeed.get();
        float gcd = Rotations.gcd(c);
        p.setYaw(p.getYaw() + Rotations.snap(humanStep(MathHelper.wrapDegrees(want[0] - p.getYaw()), max, r), gcd));
        p.setPitch(MathHelper.clamp(p.getPitch()
                + Rotations.snap(humanStep(want[1] - p.getPitch(), max * 0.6f, r), gcd), -90f, 90f));
    }

    private static float humanStep(float diff, float max, ThreadLocalRandom r) {
        float mag = Math.abs(diff);
        float step = Math.min(max, mag * 0.45f + 0.8f) * (float) r.nextDouble(0.9, 1.1);
        return Math.copySign(Math.min(step, mag), diff);
    }

    private static boolean isRail(MinecraftClient c, BlockPos pos) {
        return c.world.getBlockState(pos).isIn(BlockTags.RAILS);
    }

    private static int railSlot(ClientPlayerEntity p) {
        for (Item rail : RAILS) {
            int s = Util.findHotbar(p, rail);
            if (s >= 0) return s;
        }
        return -1;
    }

    private void fail(ClientPlayerEntity p, String msg) {
        railPos = null;
        p.sendMessage(Text.literal(msg), true);
    }

    private static void sendLook(MinecraftClient c, ClientPlayerEntity p, float yaw, float pitch) {
        if (c.getNetworkHandler() == null) return;
        c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, MathHelper.clamp(pitch, -90f, 90f), p.isOnGround(), p.horizontalCollision));
    }
}
