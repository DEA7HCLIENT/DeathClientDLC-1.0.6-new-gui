package dev.deathclient.dlc;

/** Friends: manage with ".friend add|remove|list|clear <name>". Always on by default. */
public class FriendsModule extends Module {
    /** Combat/target modules (KillAura, TPAura, Crystal/Anchor Aura, Target ESP...) ignore friends. */
    public final BoolSetting protect = add(new BoolSetting("Protect", true));
    /** Friends get their own color in Glow ESP. */
    public final BoolSetting highlight = add(new BoolSetting("Highlight", true));

    public FriendsModule() { super("Friends", Category.MISC, true); }
}
