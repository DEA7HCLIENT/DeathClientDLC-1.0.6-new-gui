package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Rotation for the block/crystal auras (Crystal Aura, Anchor Aura): turns toward the point right before the action.
 * Modes: 1 None (no rotation), 2 Silent (the server is told the aim, your camera never moves; afterwards the real
 * view is sent again), 3 Camera (your own camera turns to the point as well).
 * In Silent and Camera the aim is also shown on your model's head in third person (ServerRotation).
 */
final class AuraRotation {
    static final int NONE = 1, SILENT = 2, CAMERA = 3;

    private AuraRotation() {}

    /** The "Rotation" setting shared by the auras. */
    static NumberSetting setting() {
        return new NumberSetting("Rotation", SILENT, 1, 3, 1).labels("None", "Silent", "Camera");
    }

    /** Turns toward {@code point}; call it right before the attack / placement / click. */
    static void face(MinecraftClient c, ClientPlayerEntity p, Vec3d point, int mode) {
        if (mode == NONE) return;
        float[] r = Util.rotationsTo(p.getEyePos(), point);
        float yaw = r[0], pitch = MathHelper.clamp(r[1], -90f, 90f);
        if (mode == CAMERA) {
            p.setYaw(p.getYaw() + MathHelper.wrapDegrees(yaw - p.getYaw()));   // short way round
            p.setPitch(pitch);
        }
        send(c, p, yaw, pitch);
        ServerRotation.set(yaw, pitch, 400);
    }

    /** Silent: after the action tell the server the real view again. */
    static void restore(MinecraftClient c, ClientPlayerEntity p, int mode) {
        if (mode == SILENT) send(c, p, p.getYaw(), p.getPitch());
    }

    private static void send(MinecraftClient c, ClientPlayerEntity p, float yaw, float pitch) {
        if (c.getNetworkHandler() == null) return;
        c.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, pitch, p.isOnGround(), p.horizontalCollision));
    }
}
