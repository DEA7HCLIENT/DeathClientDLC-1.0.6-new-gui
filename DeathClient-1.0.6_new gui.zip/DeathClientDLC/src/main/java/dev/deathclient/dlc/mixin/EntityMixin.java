package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.GlowEspModule;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Client-side only: makes vanilla's own outline renderer (the spectral-arrow glow, visible through walls)
 * think a matching entity is glowing and tells it which color to use. Nothing is sent to or read from the
 * server, so server-side metadata resets cannot undo it.
 * require = 1: if either method is missing in this build, startup fails loudly instead of doing nothing.
 */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true, require = 1)
    private void deathclientdlc$glow(CallbackInfoReturnable<Boolean> cir) {
        if (GlowEspModule.colorFor((Entity) (Object) this) != -1) cir.setReturnValue(true);
    }

    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true, require = 1)
    private void deathclientdlc$glowColor(CallbackInfoReturnable<Integer> cir) {
        int color = GlowEspModule.colorFor((Entity) (Object) this);
        if (color != -1) cir.setReturnValue(color);
    }
}
