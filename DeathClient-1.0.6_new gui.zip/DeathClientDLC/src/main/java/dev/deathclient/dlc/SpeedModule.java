package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public class SpeedModule extends Module {
    public final NumberSetting speed = add(new NumberSetting("Speed", 0.35, 0.1, 1.0, 0.01));

    public SpeedModule() { super("Speed", Category.MOVEMENT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        Vec3d d = Util.inputDir(c, p);
        if (d.lengthSquared() == 0) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(d.x * speed.get(), v.y, d.z * speed.get());
    }
}
