package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;

/**
 * Frosted-glass ClickGUI: one translucent, theme-tinted, rounded panel per category, laid out in a
 * centered row. Enabled modules get a check mark.
 * LMB header: drag. RMB header: collapse. LMB module: toggle. RMB module: settings.
 * LMB bool setting: toggle. LMB/drag number setting: slider.
 */
public class ClickGuiScreen extends Screen {
    private static final int W = 104, HEAD = 22, ROW = 16, SROW = 16, GAP = 10, PANEL_R = 7, BOTTOM_PAD = 5;
    /** Corner radius in GUI pixels. */
    private static final int R = 4;
    private static final int PAD = 6;


    private static final int BG = 0xE0141414, SETTING_BG = 0xE01E1E1E, HEADER = 0xFF1E1E1E;
    private static final int TRACK = 0xFF333333, HOVER = 0x30FFFFFF;
    private static final int WHITE = 0xFFFFFFFF, MUTED = 0xFFAAAAAA;
    private static final int SWATCH = 10, SWATCH_GAP = 4;

    private static final class Panel {
        final Category cat;
        int x, y;
        boolean open = true;
        Panel(Category cat, int x, int y) { this.cat = cat; this.x = x; this.y = y; }
    }

    /** Static so panel positions survive reopening the screen. */
    private static List<Panel> panels;
    private static boolean placed;

    private Panel dragPanel;
    private double dragDX, dragDY;
    private NumberSetting dragSetting;
    private Panel dragSettingPanel;

    public ClickGuiScreen() {
        super(Text.literal("DeathClientDLC"));
        if (panels == null) {
            panels = new ArrayList<>();
            for (Category c : Category.values()) {
                if (ModuleManager.of(c).isEmpty()) continue;
                panels.add(new Panel(c, 0, 0));
            }
        }
    }

    @Override
    protected void init() {
        if (placed) return;
        placed = true;
        // Split the panels into rows that fit the screen, then center every row.
        int perRow = Math.max(1, (width - 8 + GAP) / (W + GAP));
        int y = 62;
        for (int start = 0; start < panels.size(); start += perRow) {
            List<Panel> row = panels.subList(start, Math.min(panels.size(), start + perRow));
            int rowW = row.size() * W + (row.size() - 1) * GAP;
            int rowH = 0;
            for (Panel p : row) rowH = Math.max(rowH, panelHeight(p));
            int x = (width - rowW) / 2;
            int yy = start == 0 && panels.size() <= perRow ? Math.max(62, (height - rowH) / 2) : y;
            for (Panel p : row) { p.x = x; p.y = yy; x += W + GAP; }
            y = yy + rowH + GAP;
        }
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static int inset(int r, int i) {
        double dy = r - i - 0.5;
        return (int) Math.round(r - Math.sqrt(r * r - dy * dy));
    }

    /** Filled rect with optional rounded top and/or bottom corners (one scanline per corner row). */
    static void rect(DrawContext ctx, int x, int y, int w, int h, int color, boolean top, boolean bottom) {
        int r = Math.min(R, h / 2);
        int t = top ? r : 0, b = bottom ? r : 0;
        for (int i = 0; i < t; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + i, x + w - in, y + i + 1, color);
        }
        for (int i = 0; i < b; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
        ctx.fill(x, y + t, x + w, y + h - b, color);
    }

    /** Fully rounded rectangle with its own corner radius. */
    private static void rrect(DrawContext ctx, int x, int y, int w, int h, int color, int r) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            ctx.fill(x + in, y + i, x + w - in, y + i + 1, color);
            ctx.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    /** Pixel-art check mark, 6 x 5 px, top-left at (x, y). */
    private static void check(DrawContext ctx, int x, int y, int color) {
        int[][] px = {{0, 2}, {1, 3}, {2, 4}, {3, 3}, {4, 2}, {5, 1}, {6, 0}};
        for (int[] q : px) ctx.fill(x + q[0], y + q[1], x + q[0] + 1, y + q[1] + 2, color);
    }

    private int panelHeight(Panel p) {
        int h = HEAD;
        if (!p.open) return h;
        for (Module m : ModuleManager.of(p.cat)) {
            h += ROW;
            if (m.expanded) h += SROW * m.getSettings().size();
        }
        return h + BOTTOM_PAD;
    }

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawTextWithShadow(textRenderer, s, x, y, color);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        // In a world: draw nothing (no blur, no dimming) so the game stays visible.
        if (client != null && client.world != null) return;
        Ui.drawBackground(ctx, width, height);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        Ui.drawTitle(ctx, width);
        String hint = "LMB toggle   RMB settings   MMB bind   menu: [" + Binds.name(Binds.menuKey()) + "]";
        text(ctx, hint, (width - textRenderer.getWidth(hint)) / 2, height - 14, MUTED);
        renderThemeSwatches(ctx, mx, my);
        for (Panel p : panels) renderPanel(ctx, p, mx, my);
    }

    private int swatchesX() {
        Theme[] themes = Theme.values();
        int w = themes.length * SWATCH + (themes.length - 1) * SWATCH_GAP;
        return (width - w) / 2;
    }

    private void renderThemeSwatches(DrawContext ctx, int mx, int my) {
        Theme[] themes = Theme.values();
        int x = swatchesX(), y = height - 28;
        for (Theme t : themes) {
            boolean active = t == Theme.current();
            int size = active ? SWATCH + 2 : SWATCH;
            int yy = y - (size - SWATCH);
            rect(ctx, x, yy, size, size, t.accent(), true, true);
            if (active || in(mx, my, x, yy, size, size)) rect(ctx, x, yy, size, size, HOVER, true, true);
            x += SWATCH + SWATCH_GAP;
        }
    }

    private void renderPanel(DrawContext ctx, Panel p, int mx, int my) {
        int accent = Theme.current().accent() & 0xFFFFFF;
        int glass = 0xA6000000 | accent;                       // translucent theme tint
        int h = p.open ? panelHeight(p) : HEAD;
        rrect(ctx, p.x, p.y, W, h, glass, PANEL_R);
        rrect(ctx, p.x, p.y, W, h, 0x14FFFFFF, PANEL_R);       // faint lighter sheen

        // Header: category name + small status dot, thin divider underneath.
        text(ctx, p.cat.label, p.x + 9, p.y + 7, WHITE);
        int dot = p.open ? 0xFFFFFFFF : 0x80FFFFFF;
        rrect(ctx, p.x + W - 15, p.y + 8, 6, 6, dot, 3);
        if (!p.open) return;
        ctx.fill(p.x + 7, p.y + HEAD - 1, p.x + W - 7, p.y + HEAD, 0x40FFFFFF);

        int y = p.y + HEAD + 2;
        for (Module m : ModuleManager.of(p.cat)) {
            boolean hover = in(mx, my, p.x, y, W, ROW);
            if (hover) rrect(ctx, p.x + 4, y, W - 8, ROW, 0x26FFFFFF, 4);
            else if (m.isEnabled()) rrect(ctx, p.x + 4, y, W - 8, ROW, 0x16FFFFFF, 4);
            text(ctx, m.getName(), p.x + 9, y + 4, m.isEnabled() ? WHITE : 0xFFD6D6D6);

            // Right side: bind (if any), settings arrow, check mark when enabled.
            int rx = p.x + W - 10;
            if (m.isEnabled()) check(ctx, rx - 6, y + 5, 0xFFFFFFFF);
            else if (!m.getSettings().isEmpty()) text(ctx, m.expanded ? "v" : ">", rx - 5, y + 4, MUTED);
            String bind = Binds.listening() == m ? "..." : (m.getKey() != -1 ? "[" + Binds.name(m.getKey()) + "]" : null);
            if (bind != null) text(ctx, bind, rx - 12 - textRenderer.getWidth(bind), y + 4, MUTED);
            y += ROW;

            if (!m.expanded) continue;
            for (Setting s : m.getSettings()) {
                ctx.fill(p.x + 6, y, p.x + W - 6, y + SROW, 0x44000000);
                if (s instanceof BoolSetting b) {
                    text(ctx, b.name, p.x + PAD + 4, y + 4, WHITE);
                    String v = b.get() ? "ON" : "OFF";
                    text(ctx, v, p.x + W - PAD - 4 - textRenderer.getWidth(v), y + 4, b.get() ? 0xFFFFFFFF : MUTED);
                } else if (s instanceof NumberSetting n) {
                    text(ctx, n.name, p.x + PAD + 4, y + 2, WHITE);
                    String v = String.format(n.step < 0.1 ? "%.2f" : "%.1f", n.get());
                    text(ctx, v, p.x + W - PAD - 4 - textRenderer.getWidth(v), y + 2, MUTED);
                    int trackW = W - 2 * PAD - 8;
                    int fillW = (int) (trackW * (n.get() - n.min) / (n.max - n.min));
                    ctx.fill(p.x + PAD + 4, y + SROW - 5, p.x + PAD + 4 + trackW, y + SROW - 3, 0x66FFFFFF);
                    ctx.fill(p.x + PAD + 4, y + SROW - 5, p.x + PAD + 4 + fillW, y + SROW - 3, 0xFFFFFFFF);
                }
                y += SROW;
            }
        }
    }

    private boolean clickPanel(Panel p, double mx, double my, int btn) {
        if (in(mx, my, p.x, p.y, W, HEAD)) {
            if (btn == 0) { dragPanel = p; dragDX = mx - p.x; dragDY = my - p.y; }
            else if (btn == 1) p.open = !p.open;
            return true;
        }
        if (!p.open) return false;

        int y = p.y + HEAD + 2;
        for (Module m : ModuleManager.of(p.cat)) {
            if (in(mx, my, p.x, y, W, ROW)) {
                if (btn == 0) m.toggle();
                else if (btn == 1 && !m.getSettings().isEmpty()) m.expanded = !m.expanded;
                else if (btn == 2) Binds.listen(m);
                return true;
            }
            y += ROW;
            if (!m.expanded) continue;
            for (Setting s : m.getSettings()) {
                if (in(mx, my, p.x, y, W, SROW)) {
                    if (btn == 0) {
                        if (s instanceof BoolSetting b) b.toggle();
                        else if (s instanceof NumberSetting n) {
                            dragSetting = n;
                            dragSettingPanel = p;
                            updateSlider(mx);
                        }
                    }
                    return true;
                }
                y += SROW;
            }
        }
        return false;
    }

    private void updateSlider(double mx) {
        double t = Math.max(0, Math.min(1, (mx - (dragSettingPanel.x + PAD + 4)) / (W - 2 * PAD - 8)));
        dragSetting.set(dragSetting.min + t * (dragSetting.max - dragSetting.min));
    }

    private boolean clickThemeSwatches(double mx, double my) {
        Theme[] themes = Theme.values();
        int x = swatchesX(), y = height - 28 - 2;
        int size = SWATCH + 2;
        for (Theme t : themes) {
            if (in(mx, my, x, y, size, size)) { Theme.set(t); return true; }
            x += SWATCH + SWATCH_GAP;
        }
        return false;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0 && clickThemeSwatches(click.x(), click.y())) return true;
        for (int i = panels.size() - 1; i >= 0; i--) {
            Panel p = panels.get(i);
            if (clickPanel(p, click.x(), click.y(), click.button())) {
                panels.remove(i);
                panels.add(p);
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragPanel != null) {
            dragPanel.x = (int) (click.x() - dragDX);
            dragPanel.y = (int) (click.y() - dragDY);
            return true;
        }
        if (dragSetting != null) {
            updateSlider(click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragPanel = null;
        dragSetting = null;
        dragSettingPanel = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean shouldPause() { return false; }
}
