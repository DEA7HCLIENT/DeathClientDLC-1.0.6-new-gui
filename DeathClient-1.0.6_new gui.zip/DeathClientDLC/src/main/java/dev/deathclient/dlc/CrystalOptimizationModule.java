package dev.deathclient.dlc;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.ActionResult;
import java.util.ArrayList;
import java.util.List;

/** Removes an End Crystal on the client the moment you attack it (the attack packet still goes out). */
public class CrystalOptimizationModule extends Module {
    private final List<Entity> pending = new ArrayList<>();

    public CrystalOptimizationModule() {
        super("Crystal Optimization", Category.COMBAT);
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (isEnabled() && world.isClient() && entity instanceof EndCrystalEntity) pending.add(entity);
            return ActionResult.PASS;
        });
    }

    @Override
    public void onTick(MinecraftClient c) {
        for (Entity e : pending) e.discard();
        pending.clear();
    }

    @Override
    protected void onDisable() { pending.clear(); }
}
