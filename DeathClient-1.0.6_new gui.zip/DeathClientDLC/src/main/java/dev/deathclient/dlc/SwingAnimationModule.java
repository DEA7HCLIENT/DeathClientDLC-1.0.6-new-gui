package dev.deathclient.dlc;

/** Overrides the local player's hand swing duration (see LivingEntityMixin). Vanilla is 6 ticks. */
public class SwingAnimationModule extends Module {
    public final NumberSetting duration = add(new NumberSetting("Duration", 6, 1, 20, 1));

    public SwingAnimationModule() { super("Swing Animation", Category.RENDER); }

    public int duration() { return (int) duration.get(); }
}
