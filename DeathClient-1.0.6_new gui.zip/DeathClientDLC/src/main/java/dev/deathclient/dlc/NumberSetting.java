package dev.deathclient.dlc;

public class NumberSetting extends Setting {
    public final double min, max, step;
    private double value;

    public NumberSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.min = min; this.max = max; this.step = step;
        set(value);
    }

    public double get() { return value; }

    public void set(double v) {
        double snapped = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, snapped));
    }
}
