package dev.deathclient.dlc;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Module keybinds and the ClickGUI open key: captured in the GUI (middle click) or with
 * ".bind" in chat, polled manually each tick (not Minecraft's own KeyBinding), persisted
 * in the config folder.
 */
public final class Binds {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("deathclientdlc.properties");
    private static Module listening;
    private static int menuKey = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private static boolean menuKeyDown;

    private Binds() {}

    public static void listen(Module m) { listening = m; }
    public static Module listening() { return listening; }

    public static int menuKey() { return menuKey; }

    public static void setMenuKey(int key) {
        menuKey = key;
        save();
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        Properties props = new Properties();
        try (var in = Files.newInputStream(FILE)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }
        for (Module m : ModuleManager.all()) {
            String v = props.getProperty("bind." + m.getName());
            if (v == null) continue;
            try { m.setKey(Integer.parseInt(v.trim())); } catch (NumberFormatException ignored) {}
        }
        String mk = props.getProperty("menu.key");
        if (mk != null) try { menuKey = Integer.parseInt(mk.trim()); } catch (NumberFormatException ignored) {}
    }

    public static void save() {
        Properties props = new Properties();
        for (Module m : ModuleManager.all()) {
            if (m.getKey() != -1) props.setProperty("bind." + m.getName(), Integer.toString(m.getKey()));
        }
        props.setProperty("menu.key", Integer.toString(menuKey));
        try {
            Files.createDirectories(FILE.getParent());
            try (var out = Files.newOutputStream(FILE)) {
                props.store(out, "DeathClientDLC keybinds (GLFW key codes)");
            }
        } catch (IOException ignored) {}
    }

    /** Called every client tick, with or without a world. */
    public static void tick(MinecraftClient c) {
        long window = c.getWindow().getHandle();

        if (listening != null) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                if (GLFW.glfwGetKey(window, k) != GLFW.GLFW_PRESS) continue;
                if (k == GLFW.GLFW_KEY_ESCAPE) {
                    listening = null;                       // cancel
                    return;
                }
                listening.setKey(k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE ? -1 : k);
                listening.keyDown = true;                   // don't toggle on the same press
                listening = null;
                save();
                return;
            }
            return;
        }

        // Open/close the ClickGUI on the bound key, from anywhere except typing in another screen.
        if (menuKey != -1) {
            boolean down = GLFW.glfwGetKey(window, menuKey) == GLFW.GLFW_PRESS;
            if (down && !menuKeyDown) {
                if (c.currentScreen instanceof ClickGuiScreen) c.setScreen(null);
                else if (c.currentScreen == null) c.setScreen(new ClickGuiScreen());
            }
            menuKeyDown = down;
        }

        boolean canToggle = c.player != null && c.currentScreen == null;
        for (Module m : ModuleManager.all()) {
            if (m.getKey() == -1) continue;
            boolean down = GLFW.glfwGetKey(window, m.getKey()) == GLFW.GLFW_PRESS;
            if (down && !m.keyDown && canToggle) m.toggle();
            m.keyDown = down;
        }
    }

    public static String name(int key) {
        if (key == -1) return "none";
        if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F12) return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
        switch (key) {
            case GLFW.GLFW_KEY_SPACE: return "Space";
            case GLFW.GLFW_KEY_TAB: return "Tab";
            case GLFW.GLFW_KEY_ENTER: return "Enter";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LShift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RShift";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCtrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCtrl";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LAlt";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RAlt";
            case GLFW.GLFW_KEY_UP: return "Up";
            case GLFW.GLFW_KEY_DOWN: return "Down";
            case GLFW.GLFW_KEY_LEFT: return "Left";
            case GLFW.GLFW_KEY_RIGHT: return "Right";
            case GLFW.GLFW_KEY_INSERT: return "Ins";
            case GLFW.GLFW_KEY_HOME: return "Home";
            case GLFW.GLFW_KEY_END: return "End";
            case GLFW.GLFW_KEY_PAGE_UP: return "PgUp";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "PgDn";
            default:
                String n = GLFW.glfwGetKeyName(key, 0);
                return n != null ? n.toUpperCase() : "K" + key;
        }
    }

    /** Parses a key name as typed in chat (".bind killaura f6"). -1 = clear, -2 = not recognized. */
    public static int keyByName(String raw) {
        String s = raw.trim().toUpperCase();
        if (s.equals("NONE") || s.equals("CLEAR")) return -1;
        if (s.length() == 1) {
            char ch = s.charAt(0);
            if (ch >= 'A' && ch <= 'Z') return GLFW.GLFW_KEY_A + (ch - 'A');
            if (ch >= '0' && ch <= '9') return GLFW.GLFW_KEY_0 + (ch - '0');
        }
        if (s.matches("F([1-9]|1[0-2])")) return GLFW.GLFW_KEY_F1 + (Integer.parseInt(s.substring(1)) - 1);
        return switch (s) {
            case "SPACE" -> GLFW.GLFW_KEY_SPACE;
            case "TAB" -> GLFW.GLFW_KEY_TAB;
            case "ENTER" -> GLFW.GLFW_KEY_ENTER;
            case "LSHIFT" -> GLFW.GLFW_KEY_LEFT_SHIFT;
            case "RSHIFT" -> GLFW.GLFW_KEY_RIGHT_SHIFT;
            case "LCTRL" -> GLFW.GLFW_KEY_LEFT_CONTROL;
            case "RCTRL" -> GLFW.GLFW_KEY_RIGHT_CONTROL;
            case "LALT" -> GLFW.GLFW_KEY_LEFT_ALT;
            case "RALT" -> GLFW.GLFW_KEY_RIGHT_ALT;
            case "UP" -> GLFW.GLFW_KEY_UP;
            case "DOWN" -> GLFW.GLFW_KEY_DOWN;
            case "LEFT" -> GLFW.GLFW_KEY_LEFT;
            case "RIGHT" -> GLFW.GLFW_KEY_RIGHT;
            case "INS" -> GLFW.GLFW_KEY_INSERT;
            case "HOME" -> GLFW.GLFW_KEY_HOME;
            case "END" -> GLFW.GLFW_KEY_END;
            case "PGUP" -> GLFW.GLFW_KEY_PAGE_UP;
            case "PGDN" -> GLFW.GLFW_KEY_PAGE_DOWN;
            default -> -2;
        };
    }
}
