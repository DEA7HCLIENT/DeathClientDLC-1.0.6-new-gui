import sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

def make(font_path, out, text="Death Client", size=150, tracking=6, W=1100, H=230):
    f = ImageFont.truetype(font_path, size)
    # measure with tracking
    widths = [f.getlength(c) for c in text]
    total = sum(widths) + tracking * (len(text) - 1)
    x0 = (W - total) / 2
    mask = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(mask)
    asc, desc = f.getmetrics()
    y0 = (H - (asc + desc)) / 2
    x = x0
    for c, w in zip(text, widths):
        d.text((x, y0), c, font=f, fill=255)
        x += w + tracking
    # vertical gradient white -> crimson
    grad = Image.new("RGBA", (W, H))
    gp = grad.load()
    for yy in range(H):
        t = max(0, min(1, (yy - y0) / (asc + desc)))
        r = int(255 + (190 - 255) * t); g = int(255 + (28 - 255) * t); b = int(255 + (42 - 255) * t)
        for xx in range(W):
            gp[xx, yy] = (r, g, b, 255)
    text_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    text_layer.paste(grad, (0, 0), mask)
    # glow
    glow_mask = mask.filter(ImageFilter.GaussianBlur(14))
    glow = Image.new("RGBA", (W, H), (200, 30, 45, 0))
    glow.putalpha(glow_mask.point(lambda v: min(255, int(v * 1.1))))
    # dark outline
    outline_mask = mask.filter(ImageFilter.MaxFilter(7)).filter(ImageFilter.GaussianBlur(1))
    outline = Image.new("RGBA", (W, H), (20, 0, 4, 0))
    outline.putalpha(outline_mask)
    img = Image.alpha_composite(Image.alpha_composite(glow, outline), text_layer)
    img.save(out)
    return img

if __name__ == "__main__":
    cands = {
      "baskerville": "/usr/share/fonts/truetype/baskerville/GFSBaskerville.otf",
      "caladea_bi": "/usr/share/fonts/truetype/crosextra/Caladea-BoldItalic.ttf",
      "dejavu_serif_b": "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf",
    }
    sheet = Image.new("RGBA", (1100, 230 * 3), (22, 22, 22, 255))
    for i, (k, p) in enumerate(cands.items()):
        im = make(p, f"t_{k}.png")
        sheet.alpha_composite(im, (0, 230 * i))
    sheet.convert("RGB").save("sheet.png")
