package dev.deathclient.dlc;

/**
 * Custom Theme: the four colours used by the themes "Custom 1" to "Custom 4" (they use the first 1, 2, 3 or 4 of
 * them). Every colour is set with Hue (0-360), Saturation and Brightness (0-100). Edit them here, then pick the
 * theme in the Themes tab, where its swatch shows the result. The module is always on; there is nothing to switch.
 */
public class CustomThemeModule extends Module {
    private static final double[][] DEFAULTS = {            // hue, saturation, brightness
            {350, 80, 85}, {40, 85, 95}, {160, 75, 85}, {260, 70, 90}};

    private final NumberSetting[][] hsb = new NumberSetting[4][3];

    public CustomThemeModule() {
        super("Custom Theme", Category.MISC, true);
        for (int i = 0; i < 4; i++) {
            hsb[i][0] = add(new NumberSetting("Color " + (i + 1) + " Hue", DEFAULTS[i][0], 0, 360, 1));
            hsb[i][1] = add(new NumberSetting("Color " + (i + 1) + " Sat", DEFAULTS[i][1], 0, 100, 1));
            hsb[i][2] = add(new NumberSetting("Color " + (i + 1) + " Bri", DEFAULTS[i][2], 0, 100, 1));
        }
    }

    /** The first {@code count} colours as 0xFFRRGGBB. */
    static int[] colors(int count) {
        CustomThemeModule m = ModuleManager.get(CustomThemeModule.class);
        int[] out = new int[count];
        for (int i = 0; i < count; i++) {
            out[i] = m == null ? fromHsb(DEFAULTS[i][0], DEFAULTS[i][1], DEFAULTS[i][2])
                    : fromHsb(m.hsb[i][0].get(), m.hsb[i][1].get(), m.hsb[i][2].get());
        }
        return out;
    }

    private static int fromHsb(double hue, double sat, double bri) {
        double h = (hue % 360) / 60.0, s = sat / 100.0, v = bri / 100.0;
        int sector = (int) Math.floor(h);
        double f = h - sector, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        double r, g, b;
        switch (sector) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return 0xFF000000 | ((int) Math.round(r * 255) << 16) | ((int) Math.round(g * 255) << 8) | (int) Math.round(b * 255);
    }
}
