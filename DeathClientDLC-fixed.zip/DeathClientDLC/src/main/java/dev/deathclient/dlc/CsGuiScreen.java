package dev.deathclient.dlc;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;

/**
 * ClickGUI style "CS": the look of a Counter-Strike cheat menu. A flat dark window with a thin theme-coloured line
 * on top, a tab column on the left (categories + Themes), group boxes with a title cut into the frame, small
 * square check boxes and thin sliders. Left box: the modules of the tab; right box: settings of the selected module.
 * LMB module: toggle. RMB module: show its settings. MMB module: bind. Number settings with names (modes): LMB next, RMB previous.
 */
public class CsGuiScreen extends Screen {
    private static final int WW = 400, WH = 270, TABW = 78, TOP = 22, ROW = 13, TAB_H = 20;
    private static final int BORDER = 0xFF0A0A0A, EDGE = 0xFF3A3A3A, BG = 0xFF141414, BOX_BG = 0xFF181818, TAB_BG = 0xFF101010;
    private static final int WHITE = 0xFFE6E6E6, MUTED = 0xFF8A8A8A, DIM = 0xFF5A5A5A, TRACK = 0xFF2A2A2A;

    private static int winX, winY;
    private static boolean placed;
    private static Category selCat = Category.COMBAT;     // null = Themes tab
    private static boolean themesTab;
    private static Module selMod;

    /** Glass Menu is on (set every frame). */
    private boolean glass;

    private final List<Category> cats = new ArrayList<>();
    private double scroll;
    private boolean draggingWin;
    private double dragDX, dragDY;
    private NumberSetting dragSetting;
    private int dragX, dragW;

    public CsGuiScreen() { super(Text.literal("Death Client")); }

    @Override
    protected void init() {
        cats.clear();
        for (Category c : Category.values()) if (!ModuleManager.of(c).isEmpty()) cats.add(c);
        if (!cats.contains(selCat) && !cats.isEmpty()) selCat = cats.get(0);
        if (!placed) { winX = (width - WW) / 2; winY = (height - WH) / 2; placed = true; }
        winX = Math.max(0, Math.min(winX, Math.max(0, width - WW)));
        winY = Math.max(0, Math.min(winY, Math.max(0, height - WH)));
        fixSelected();
    }

    @Override
    public void tick() {
        super.tick();
        if (client != null && GuiStyleModule.style() != GuiStyleModule.CS) client.setScreen(GuiStyleModule.create());
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (client != null && client.world != null) super.renderBackground(ctx, mx, my, delta);
        else Ui.drawBackground(ctx, width, height);
    }

    // ------------------------------------------------------------------ layout

    private int lx() { return winX + TABW + 8; }
    private int ly() { return winY + TOP + 4; }
    private int lw() { return 138; }
    private int lh() { return WH - TOP - 12; }
    private int rx() { return lx() + lw() + 8; }
    private int rw() { return winX + WW - 8 - rx(); }

    private List<Module> modules() { return themesTab || selCat == null ? List.of() : ModuleManager.of(selCat); }

    /** The module whose settings are shown: the chosen one, else the first of the tab (Themes tab: the GUI Style module). */
    private void fixSelected() {
        if (themesTab) { selMod = ModuleManager.get(GuiStyleModule.class); return; }
        List<Module> list = modules();
        if (selMod == null || !list.contains(selMod)) selMod = list.isEmpty() ? null : list.get(0);
    }

    private static int heightOf(Setting s) { return s instanceof NumberSetting n && n.label() == null ? 22 : 14; }

    private int listHeight() {
        return themesTab ? Theme.values().length * ROW : modules().size() * ROW;
    }

    private double maxScroll() { return Math.max(0, listHeight() - (lh() - 16)); }

    // ------------------------------------------------------------------ drawing helpers

    private void text(DrawContext ctx, String s, int x, int y, int color) {
        ctx.drawTextWithShadow(textRenderer, s, x, y, color);
    }

    private static void frame(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + 1, color);
        ctx.fill(x, y + h - 1, x + w, y + h, color);
        ctx.fill(x, y, x + 1, y + h, color);
        ctx.fill(x + w - 1, y, x + w, y + h, color);
    }

    private void groupBox(DrawContext ctx, int x, int y, int w, int h, String title) {
        int tw = textRenderer.getWidth(title);
        if (glass) {
            ctx.fill(x, y, x + w, y + h, 0x20FFFFFF);
            // Frame with a gap in the top line for the title (the window behind is see-through, so no patch over it).
            int c = 0x55FFFFFF, gx0 = x + 6, gx1 = x + 6 + tw + 6;
            ctx.fill(x, y, gx0, y + 1, c);
            ctx.fill(gx1, y, x + w, y + 1, c);
            ctx.fill(x, y + h - 1, x + w, y + h, c);
            ctx.fill(x, y, x + 1, y + h, c);
            ctx.fill(x + w - 1, y, x + w, y + h, c);
        } else {
            ctx.fill(x, y, x + w, y + h, BOX_BG);
            frame(ctx, x, y, w, h, 0xFF2C2C2C);
            frame(ctx, x - 1, y - 1, w + 2, h + 2, BORDER);
            ctx.fill(x + 6, y - 1, x + 6 + tw + 6, y + 1, BG);               // cut the title into the frame
        }
        text(ctx, title, x + 9, y - 4, WHITE);
    }

    private void checkbox(DrawContext ctx, int x, int y, boolean on, int acc) {
        ctx.fill(x, y, x + 8, y + 8, BORDER);
        ctx.fill(x + 1, y + 1, x + 7, y + 7, on ? 0xFF000000 | acc : (glass ? 0xFF3A3A44 : 0xFF262626));
        if (on) ctx.fill(x + 1, y + 1, x + 7, y + 3, 0x30FFFFFF);
    }

    private void gradLine(DrawContext ctx, int x, int y, int w, int h) {
        Theme t = Theme.current();
        if (!t.gradient()) { ctx.fill(x, y, x + w, y + h, 0xFF000000 | t.accent()); return; }
        for (int i = 0; i < w; i += 2) ctx.fill(x + i, y, Math.min(x + w, x + i + 2), y + h, 0xFF000000 | (t.at((i + 1f) / w) & 0xFFFFFF));
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        scroll = Math.max(0, Math.min(scroll, maxScroll()));
        int acc = Theme.current().accent();

        // Window: black outline, light inner edge, body, gradient line on top.
        GlassMenuModule gm = ModuleManager.get(GlassMenuModule.class);
        glass = gm != null && gm.isEnabled();
        if (glass) {
            // Glass: translucent tinted pane, light rim, soft band of light along the top.
            int a = (int) (gm.opacity.get() * 2.55);
            int tint = ClickGuiScreen.mix(0xFF0B0D14, acc, (float) (gm.tint.get() / 100.0) * 0.5f) & 0xFFFFFF;
            ctx.fill(winX, winY, winX + WW, winY + WH, (a << 24) | tint);
            if (gm.shine.get()) ctx.fillGradient(winX, winY + 2, winX + WW, winY + 2 + WH * 2 / 5, 0x2CFFFFFF, 0x00FFFFFF);
            if (gm.border.get()) {
                frame(ctx, winX - 1, winY - 1, WW + 2, WH + 2, 0x70FFFFFF);
                frame(ctx, winX, winY, WW, WH, 0x14FFFFFF);
            }
        } else {
            frame(ctx, winX - 2, winY - 2, WW + 4, WH + 4, BORDER);
            frame(ctx, winX - 1, winY - 1, WW + 2, WH + 2, EDGE);
            ctx.fill(winX, winY, winX + WW, winY + WH, BG);
        }
        gradLine(ctx, winX, winY, WW, 2);
        text(ctx, "DEATH", winX + 8, winY + 7, WHITE);
        text(ctx, "client", winX + 8 + textRenderer.getWidth("DEATH "), winY + 7, 0xFF000000 | acc);

        // Tabs.
        ctx.fill(winX, winY + TOP, winX + TABW, winY + WH, glass ? 0x38000000 : TAB_BG);
        ctx.fill(winX + TABW, winY + TOP, winX + TABW + 1, winY + WH, glass ? 0x30FFFFFF : BORDER);
        int ty = winY + TOP + 6;
        for (Category c : cats) { tab(ctx, mx, my, ty, c.label, !themesTab && c == selCat, acc); ty += TAB_H; }
        tab(ctx, mx, my, ty, "Themes", themesTab, acc);

        // Left box.
        int lx = lx(), ly = ly(), lw = lw(), lh = lh();
        groupBox(ctx, lx, ly, lw, lh, themesTab ? "Themes" : selCat.label);
        ctx.enableScissor(lx, ly + 6, lx + lw, ly + lh - 2);
        int y = ly + 10 - (int) scroll;
        if (themesTab) {
            for (Theme t : Theme.values()) {
                boolean hover = ClickGuiScreen.in(mx, my, lx + 2, y, lw - 4, ROW);
                if (hover) ctx.fill(lx + 2, y, lx + lw - 2, y + ROW, glass ? 0x24FFFFFF : 0xFF202020);
                for (int i = 0; i < 12; i++) ctx.fill(lx + 8 + i, y + 2, lx + 9 + i, y + ROW - 2, 0xFF000000 | (t.at(i / 11f) & 0xFFFFFF));
                text(ctx, t.label, lx + 26, y + 3, t == Theme.current() ? WHITE : MUTED);
                y += ROW;
            }
        } else {
            for (Module m : modules()) {
                boolean hover = ClickGuiScreen.in(mx, my, lx + 2, y, lw - 4, ROW);
                if (m == selMod) ctx.fill(lx + 2, y, lx + lw - 2, y + ROW, glass ? 0x30FFFFFF : 0xFF1E1E1E);
                else if (hover) ctx.fill(lx + 2, y, lx + lw - 2, y + ROW, glass ? 0x20FFFFFF : 0xFF1A1A1A);
                checkbox(ctx, lx + 8, y + 2, m.isEnabled(), acc);
                text(ctx, m.getName(), lx + 22, y + 3, m.isEnabled() ? WHITE : MUTED);
                if (Binds.listening() == m) text(ctx, "...", lx + lw - 8 - textRenderer.getWidth("..."), y + 3, DIM);
                else if (m.getKey() != -1) {
                    String k = "[" + Binds.name(m.getKey()) + "]";
                    text(ctx, k, lx + lw - 8 - textRenderer.getWidth(k), y + 3, DIM);
                }
                y += ROW;
            }
        }
        ctx.disableScissor();

        // Right box.
        int rx = rx(), rw = rw();
        String rtitle = selMod == null ? "Settings" : selMod.getName();
        groupBox(ctx, rx, ly, rw, lh, rtitle);
        if (selMod == null) return;
        int sy = ly + 10;
        String desc = ModuleInfo.desc(selMod);
        if (!desc.isEmpty()) {
            for (String line : wrap(desc, rw - 16)) { text(ctx, line, rx + 8, sy, DIM); sy += 10; }
            sy += 4;
        }
        if (selMod.getSettings().isEmpty()) text(ctx, "No settings", rx + 8, sy, DIM);
        for (Setting s : selMod.getSettings()) {
            drawSetting(ctx, s, rx + 8, sy, rw - 16, mx, my, acc);
            sy += heightOf(s);
        }
        String bind = Binds.listening() == selMod ? "Press any key..." : "Bind: " + Binds.name(selMod.getKey());
        text(ctx, bind, rx + rw - 8 - textRenderer.getWidth(bind), ly + lh - 14, ClickGuiScreen.in(mx, my, rx + rw - 12 - textRenderer.getWidth(bind), ly + lh - 16, textRenderer.getWidth(bind) + 8, 14) ? WHITE : MUTED);
    }

    private void tab(DrawContext ctx, int mx, int my, int y, String label, boolean sel, int acc) {
        boolean hover = ClickGuiScreen.in(mx, my, winX, y, TABW, TAB_H);
        if (sel) {
            ctx.fill(winX, y, winX + TABW, y + TAB_H - 2, glass ? 0x30FFFFFF : BG);
            ctx.fill(winX, y, winX + 2, y + TAB_H - 2, 0xFF000000 | acc);
            if (!glass) ctx.fill(winX + TABW, y, winX + TABW + 1, y + TAB_H - 2, BG);   // opens the tab into the content area
        } else if (hover) ctx.fill(winX, y, winX + TABW, y + TAB_H - 2, glass ? 0x18FFFFFF : 0xFF161616);
        text(ctx, label, winX + 12, y + 5, sel ? WHITE : MUTED);
    }

    private void drawSetting(DrawContext ctx, Setting s, int x, int y, int w, int mx, int my, int acc) {
        if (s instanceof BoolSetting b) {
            checkbox(ctx, x, y + 2, b.get(), acc);
            text(ctx, b.name, x + 14, y + 3, b.get() ? WHITE : MUTED);
        } else if (s instanceof NumberSetting n) {
            if (n.label() != null) {                                              // named mode: click to cycle
                text(ctx, n.name, x, y + 3, MUTED);
                String v = "< " + n.label() + " >";
                text(ctx, v, x + w - textRenderer.getWidth(v), y + 3, WHITE);
                return;
            }
            text(ctx, n.name, x, y + 1, MUTED);
            String v = String.format(n.step < 0.1 ? "%.2f" : "%.1f", n.get());
            text(ctx, v, x + w - textRenderer.getWidth(v), y + 1, WHITE);
            int by = y + 13, fill = (int) (w * (n.get() - n.min) / (n.max - n.min));
            ctx.fill(x, by, x + w, by + 5, BORDER);
            ctx.fill(x + 1, by + 1, x + w - 1, by + 4, TRACK);
            ctx.fill(x + 1, by + 1, x + Math.max(1, fill - 1), by + 4, 0xFF000000 | acc);
        }
    }

    private List<String> wrap(String s, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : s.split(" ")) {
            String test = cur.length() == 0 ? word : cur + " " + word;
            if (textRenderer.getWidth(test) > width && cur.length() > 0) { lines.add(cur.toString()); cur = new StringBuilder(word); }
            else cur = new StringBuilder(test);
        }
        if (cur.length() > 0) lines.add(cur.toString());
        return lines;
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();
        if (!ClickGuiScreen.in(mx, my, winX, winY, WW, WH)) return super.mouseClicked(click, doubled);

        if (btn == 0 && my < winY + TOP) { draggingWin = true; dragDX = mx - winX; dragDY = my - winY; return true; }

        // Tabs.
        int ty = winY + TOP + 6;
        for (Category c : cats) {
            if (btn == 0 && ClickGuiScreen.in(mx, my, winX, ty, TABW, TAB_H)) { selCat = c; themesTab = false; selMod = null; scroll = 0; fixSelected(); return true; }
            ty += TAB_H;
        }
        if (btn == 0 && ClickGuiScreen.in(mx, my, winX, ty, TABW, TAB_H)) { themesTab = true; scroll = 0; fixSelected(); return true; }

        // Left box.
        int lx = lx(), ly = ly(), lw = lw(), lh = lh();
        if (ClickGuiScreen.in(mx, my, lx, ly + 6, lw, lh - 8)) {
            int y = ly + 10 - (int) scroll;
            if (themesTab) {
                for (Theme t : Theme.values()) {
                    if (btn == 0 && ClickGuiScreen.in(mx, my, lx + 2, y, lw - 4, ROW)) { Theme.set(t); return true; }
                    y += ROW;
                }
            } else {
                for (Module m : modules()) {
                    if (ClickGuiScreen.in(mx, my, lx + 2, y, lw - 4, ROW)) {
                        if (btn == 0) { m.toggle(); selMod = m; }
                        else if (btn == 1) selMod = m;
                        else if (btn == 2) Binds.listen(m);
                        return true;
                    }
                    y += ROW;
                }
            }
            return true;
        }

        // Right box.
        int rx = rx(), rw = rw();
        if (selMod != null && ClickGuiScreen.in(mx, my, rx, ly, rw, lh)) {
            String bind = Binds.listening() == selMod ? "Press any key..." : "Bind: " + Binds.name(selMod.getKey());
            if (btn == 0 && ClickGuiScreen.in(mx, my, rx + rw - 12 - textRenderer.getWidth(bind), ly + lh - 16, textRenderer.getWidth(bind) + 8, 14)) { Binds.listen(selMod); return true; }
            int sy = ly + 10;
            String desc = ModuleInfo.desc(selMod);
            if (!desc.isEmpty()) sy += wrap(desc, rw - 16).size() * 10 + 4;
            for (Setting s : selMod.getSettings()) {
                int h = heightOf(s);
                if (ClickGuiScreen.in(mx, my, rx + 8, sy, rw - 16, h)) {
                    if (s instanceof BoolSetting b && btn == 0) b.toggle();
                    else if (s instanceof NumberSetting n) {
                        if (n.label() != null) {
                            double next = n.get() + (btn == 1 ? -n.step : n.step);
                            if (next > n.max) next = n.min;
                            if (next < n.min) next = n.max;
                            n.set(next);
                        } else if (btn == 0) { dragSetting = n; dragX = rx + 8; dragW = rw - 16; slide(mx); }
                    }
                    return true;
                }
                sy += h;
            }
        }
        return true;
    }

    private void slide(double mx) {
        double t = Math.max(0, Math.min(1, (mx - dragX) / dragW));
        dragSetting.set(dragSetting.min + t * (dragSetting.max - dragSetting.min));
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (draggingWin) {
            winX = Math.max(0, Math.min((int) (click.x() - dragDX), Math.max(0, width - WW)));
            winY = Math.max(0, Math.min((int) (click.y() - dragDY), Math.max(0, height - WH)));
            return true;
        }
        if (dragSetting != null) { slide(click.x()); return true; }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        draggingWin = false;
        dragSetting = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (ClickGuiScreen.in(mouseX, mouseY, lx(), ly(), lw(), lh())) {
            scroll = Math.max(0, Math.min(scroll - verticalAmount * 13, maxScroll()));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() { return false; }
}
