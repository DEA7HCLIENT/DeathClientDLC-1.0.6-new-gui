package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * No Render, FOV effects: the field-of-view multiplier (speed, sprint, bow, spyglass) is always 1.
 * require = 0: if the method is named differently in this build, nothing happens.
 */
@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
    @Inject(method = "getFovMultiplier", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noFovEffects(CallbackInfoReturnable<Float> cir) {
        if (NoRenderModule.fov()) cir.setReturnValue(1.0f);
    }
}
