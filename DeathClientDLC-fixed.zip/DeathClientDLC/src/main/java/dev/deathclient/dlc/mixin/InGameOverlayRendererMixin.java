package dev.deathclient.dlc.mixin;

import dev.deathclient.dlc.NoRenderModule;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * No Render, Fire: the burning overlay is not drawn. No arguments are read, so the hook does not depend on the
 * method's signature. require = 0: if the method is named differently in this build, nothing happens.
 */
@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true, require = 0)
    private static void deathclientdlc$noFire(CallbackInfo ci) {
        if (NoRenderModule.fire()) ci.cancel();
    }
}
