package dev.deathclient.dlc.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.deathclient.dlc.ModuleManager;
import dev.deathclient.dlc.NoRenderModule;
import dev.deathclient.dlc.SwingAnimationModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    // require = 0: if the target method differs in this build the injection is skipped instead of crashing.
    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$swingDuration(CallbackInfoReturnable<Integer> cir) {
        SwingAnimationModule m = ModuleManager.get(SwingAnimationModule.class);
        if (m != null && m.isEnabled() && (Object) this == MinecraftClient.getInstance().player) {
            cir.setReturnValue(m.duration());
        }
    }

    /**
     * No Render, Potion effects: for the local player the game is told it has no Blindness / Darkness, so the fog and the
     * lightmap stay clear. The effects themselves are untouched on the server.
     */
    @Inject(method = "hasStatusEffect", at = @At("HEAD"), cancellable = true, require = 0)
    private void deathclientdlc$noVisualEffects(CallbackInfoReturnable<Boolean> cir,
                                                @Local(argsOnly = true) RegistryEntry<StatusEffect> effect) {
        if ((Object) this == MinecraftClient.getInstance().player && NoRenderModule.effects()
                && (effect.matches(StatusEffects.BLINDNESS) || effect.matches(StatusEffects.DARKNESS))) {
            cir.setReturnValue(false);
        }
    }
}
