package dev.deathclient.dlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Elytra Mace: needs an elytra on your chest and a mace in the hotbar.
 * A target between "Min distance" (7) and "Max distance" (50) blocks away starts the attack:
 * 1. Approach: you glide (jump + elytra, fireworks for speed) to a point "Dive height" blocks above the target.
 * 2. Dive: the elytra is taken off (swapped with a hotbar slot, which stops the glide on the server too), so the
 *    fall distance builds up, and you drop onto the target.
 * 3. Smash: mace in hand, one hit once the target is in reach.
 * 4. Recover: the elytra goes back on and you glide away; the next target in range starts it again.
 * Needs a hotbar slot that is empty or holds a chestplate (used for the swap) and, for the speed boost,
 * fireworks in the hotbar. This is a heuristic; it has not been checked against any server's anti-cheat.
 */
public class ElytraMaceModule extends Module {
    private static final int IDLE = 0, APPROACH = 1, DIVE = 2, RECOVER = 3;
    private static final int CHEST_SLOT = 6;          // chest armour slot in the player's screen handler

    public final NumberSetting minDistance = add(new NumberSetting("Min distance", 7, 1, 50, 1));
    public final NumberSetting maxDistance = add(new NumberSetting("Max distance", 50, 10, 50, 1));
    public final NumberSetting diveHeight = add(new NumberSetting("Dive height", 12, 5, 40, 1));
    public final NumberSetting diveSpeed = add(new NumberSetting("Dive speed", 0.9, 0.3, 2.0, 0.05));
    public final NumberSetting turnSpeed = add(new NumberSetting("Turn speed", 20, 5, 60, 1));
    public final BoolSetting fireworks = add(new BoolSetting("Fireworks", true));
    public final BoolSetting playersOnly = add(new BoolSetting("Players only", true));
    public final BoolSetting invisible = add(new BoolSetting("Invisible", true));
    public final BoolSetting restoreSlot = add(new BoolSetting("Restore slot", true));
    public final BoolSetting swing = add(new BoolSetting("Swing", true));

    private int stage = IDLE;
    private LivingEntity target;
    private int ticks, boostWait, warnWait, launchTicks;
    /** Hotbar slot swapped with the chest slot while the elytra is off, or -1. */
    private int swapSlot = -1;
    private boolean elytraOff;

    public ElytraMaceModule() { super("Elytra Mace", Category.COMBAT); }

    @Override
    public void onTick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        if (boostWait > 0) boostWait--;
        if (warnWait > 0) warnWait--;
        if (c.currentScreen != null || !p.isAlive() || p.isSpectator()) { reset(c, p); return; }

        int mace = Util.findHotbar(p, Items.MACE);
        if (mace < 0 || (!elytraOff && !p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA))) {
            if (stage != IDLE) reset(c, p);
            warn(p, mace < 0 ? "Elytra Mace: нет булавы на хотбаре" : "Elytra Mace: наденьте элитры");
            return;
        }

        switch (stage) {
            case IDLE -> idle(c, p);
            case APPROACH -> approach(c, p);
            case DIVE -> dive(c, p, mace);
            default -> recover(c, p);
        }
    }

    @Override
    protected void onDisable() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) reset(c, c.player);
    }

    // ---- stages ----

    private void idle(MinecraftClient c, ClientPlayerEntity p) {
        LivingEntity t = pick(c, p, true);
        if (t == null) return;
        if (p.isOnGround()) {                                     // elytra only opens in the air: hop first
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42, v.z);
            return;
        }
        target = t;
        launchTicks = 0;
        ticks = 0;
        stage = APPROACH;
    }

    private void approach(MinecraftClient c, ClientPlayerEntity p) {
        if (!valid(c, p, target) || p.distanceTo(target) > maxDistance.get() || ++ticks > 400) { stage = RECOVER; return; }
        if (!p.isGliding()) {
            if (p.isOnGround() || ++launchTicks > 30) { stage = RECOVER; return; }
            if (launchTicks % 2 == 1) {                           // ask for the glide until the server confirms it
                p.startGliding();
                c.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            }
            return;
        }

        double height = diveHeight.get();
        Vec3d above = Util.pos(target).add(0, height, 0);
        turn(p, Util.rotationsTo(p.getEyePos(), above));
        if (fireworks.get() && boostWait == 0 && p.getVelocity().length() < 1.0) boost(c, p);

        double dx = target.getX() - p.getX(), dz = target.getZ() - p.getZ();
        boolean overTarget = Math.sqrt(dx * dx + dz * dz) <= 8.0;
        boolean highEnough = p.getY() - target.getY() >= Math.max(4.0, height * 0.75);
        if (overTarget && highEnough) {
            if (takeOffElytra(c, p)) { stage = DIVE; ticks = 0; }
            else { warn(p, "Elytra Mace: нужен пустой слот или нагрудник на хотбаре"); stage = RECOVER; }
        }
    }

    private void dive(MinecraftClient c, ClientPlayerEntity p, int mace) {
        if (!valid(c, p, target) || ++ticks > 120 || p.isOnGround()) { stage = RECOVER; return; }
        Vec3d to = target.getBoundingBox().getCenter().subtract(p.getPos());
        double len = Math.max(to.length(), 1.0E-4);
        Vec3d v = p.getVelocity();
        double s = diveSpeed.get();
        p.setVelocity(to.x / len * s, Math.min(v.y, to.y / len * s), to.z / len * s);   // gravity keeps pulling, fall distance grows
        float[] want = Util.rotationsTo(p.getEyePos(), target.getBoundingBox().getCenter());
        p.setYaw(p.getYaw() + MathHelper.wrapDegrees(want[0] - p.getYaw()));
        p.setPitch(MathHelper.clamp(want[1], -90f, 90f));

        if (Util.reach(p, target) > 3.0 || p.getAttackCooldownProgress(0.5f) < 0.9f) return;
        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(mace);
        AuraRotation.face(c, p, target.getBoundingBox().getCenter(), AuraRotation.SILENT);
        c.interactionManager.attackEntity(p, target);
        if (swing.get()) p.swingHand(Hand.MAIN_HAND);
        AuraRotation.restore(c, p, AuraRotation.SILENT);
        if (restoreSlot.get()) p.getInventory().setSelectedSlot(prev);
        stage = RECOVER;
    }

    private void recover(MinecraftClient c, ClientPlayerEntity p) {
        putOnElytra(c, p);
        target = null;
        stage = IDLE;
        if (!p.isOnGround() && !p.isGliding() && p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
            p.startGliding();                                     // glide away from the fight
            c.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        }
    }

    // ---- helpers ----

    private void reset(MinecraftClient c, ClientPlayerEntity p) {
        putOnElytra(c, p);
        stage = IDLE;
        target = null;
    }

    /** Nearest valid target; when {@code useMin}, only between Min and Max distance. */
    private LivingEntity pick(MinecraftClient c, ClientPlayerEntity p, boolean useMin) {
        double min = Math.min(minDistance.get(), maxDistance.get()), max = Math.max(minDistance.get(), maxDistance.get());
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (Entity e : c.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !valid(c, p, le)) continue;
            double d = p.distanceTo(le);
            if (d > max || (useMin && d < min)) continue;
            if (d < bestD) { bestD = d; best = le; }
        }
        return best;
    }

    private boolean valid(MinecraftClient c, ClientPlayerEntity p, LivingEntity le) {
        if (le == null || le == p || !le.isAlive() || le.isSpectator() || le.isRemoved()) return false;
        if (playersOnly.get() && !(le instanceof PlayerEntity)) return false;
        if (Friends.skip(le)) return false;
        return invisible.get() || !le.isInvisible();
    }

    /** Camera turns toward (yaw, pitch), at most Turn speed degrees per tick: the elytra flies where you look. */
    private void turn(ClientPlayerEntity p, float[] want) {
        float max = (float) turnSpeed.get();
        float dy = MathHelper.wrapDegrees(want[0] - p.getYaw());
        float dp = want[1] - p.getPitch();
        p.setYaw(p.getYaw() + MathHelper.clamp(dy, -max, max));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dp, -max, max), -90f, 90f));
    }

    private void boost(MinecraftClient c, ClientPlayerEntity p) {
        int slot = Util.findHotbar(p, Items.FIREWORK_ROCKET);
        if (slot < 0) return;
        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        c.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.getInventory().setSelectedSlot(prev);
        boostWait = 25;
    }

    /** Swaps the elytra with a hotbar chestplate or an empty hotbar slot: that ends the glide on the server too. */
    private boolean takeOffElytra(MinecraftClient c, ClientPlayerEntity p) {
        int slot = -1;
        for (int i = 0; i < 9 && slot < 0; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isEmpty() || s.isOf(Items.NETHERITE_CHESTPLATE) || s.isOf(Items.DIAMOND_CHESTPLATE)
                    || s.isOf(Items.IRON_CHESTPLATE) || s.isOf(Items.GOLDEN_CHESTPLATE)
                    || s.isOf(Items.CHAINMAIL_CHESTPLATE) || s.isOf(Items.LEATHER_CHESTPLATE)) slot = i;
        }
        if (slot < 0) return false;
        c.interactionManager.clickSlot(p.playerScreenHandler.syncId, CHEST_SLOT, slot, SlotActionType.SWAP, p);
        swapSlot = slot;
        elytraOff = true;
        return true;
    }

    /** The same swap again puts the elytra back on. */
    private void putOnElytra(MinecraftClient c, ClientPlayerEntity p) {
        if (!elytraOff) return;
        elytraOff = false;
        if (swapSlot >= 0 && p != null && c.interactionManager != null) {
            c.interactionManager.clickSlot(p.playerScreenHandler.syncId, CHEST_SLOT, swapSlot, SlotActionType.SWAP, p);
        }
        swapSlot = -1;
    }

    private void warn(ClientPlayerEntity p, String msg) {
        if (warnWait > 0) return;
        warnWait = 100;
        p.sendMessage(Text.literal(msg), true);
    }
}
