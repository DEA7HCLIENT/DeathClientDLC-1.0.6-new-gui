package br0.neverlose;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.List;

public final class ClickGuiScreen extends Screen {
    private static final int BG = 0xF20A101B, SIDEBAR = 0xF20B2944;
    private static final int PANEL = 0xE9111A29, ACCENT = 0xFF13A9E8;
    private static final int TEXT = 0xFFE8F1FA, MUTED = 0xFF8195AA;
    private final String[] categories = {"Combat", "Movement", "Player", "Render", "Misc"};
    private String selected = "Combat", search = "";
    private boolean searching;
    private int px, py, pw = 680, ph = 440, scroll;

    public ClickGuiScreen() { super(Component.literal("NeverLoseBr0")); }

    @Override protected void init() {
        px = (width - pw) / 2;
        py = (height - ph) / 2;
    }

    private Module.Category category() {
        return Module.Category.valueOf(selected.toUpperCase());
    }

    @Override public void render(GuiGraphics g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x77000000);
        g.fill(px, py, px + pw, py + ph, BG);
        g.fill(px, py, px + 150, py + ph, SIDEBAR);
        g.fill(px, py, px + pw, py + 55, 0xFF080E17);
        g.fill(px, py, px + 4, py + ph, ACCENT);

        g.drawString(font, "NEVERLOSE", px + 17, py + 13, TEXT, false);
        g.drawString(font, "BR0  /  FABRIC 1.21.11", px + 17, py + 30, MUTED, false);
        g.drawString(font, "CONFIG  ▾", px + pw - 150, py + 22, 0xFFB7C8D9, false);
        g.drawString(font, searching ? "Search: " + search + "_" : "⌕  Search", px + pw - 82, py + 22, TEXT, false);

        int cy = py + 78;
        for (String cat : categories) {
            boolean active = cat.equals(selected);
            if (active) {
                g.fill(px + 10, cy - 6, px + 140, cy + 18, 0xFF145078);
                g.fill(px + 10, cy - 6, px + 13, cy + 18, ACCENT);
            }
            g.drawString(font, cat, px + 25, cy, active ? TEXT : MUTED, false);
            cy += 34;
        }
        g.drawString(font, "NEVERLOSEBR0", px + 17, py + ph - 36, TEXT, false);
        g.drawString(font, "v0.2.0  •  CLIENT UI", px + 17, py + ph - 21, MUTED, false);

        g.drawString(font, selected.toUpperCase() + "  /  MODULES", px + 170, py + 70, MUTED, false);
        List<Module> list = ModuleManager.in(category()).stream()
                .filter(m -> search.isBlank() || m.name().toLowerCase().contains(search.toLowerCase()))
                .toList();
        int start = Math.min(scroll, Math.max(0, list.size() - 8));
        int shown = Math.min(8, list.size() - start);
        for (int i = 0; i < shown; i++) {
            Module module = list.get(start + i);
            int col = i / 4, row = i % 4;
            int x = px + 170 + col * 245, y = py + 91 + row * 73;
            g.fill(x, y, x + 228, y + 60, PANEL);
            g.drawString(font, module.name(), x + 12, y + 11, TEXT, false);
            String desc = module.description();
            if (desc.length() > 32) desc = desc.substring(0, 29) + "...";
            g.drawString(font, desc, x + 12, y + 28, MUTED, false);
            int sx = x + 199, sy = y + 18;
            g.fill(sx - 10, sy - 7, sx + 10, sy + 7, module.enabled() ? ACCENT : 0xFF465568);
            g.fill(module.enabled() ? sx + 1 : sx - 9, sy - 6,
                    module.enabled() ? sx + 9 : sx - 1, sy + 6, 0xFFFFFFFF);
        }
        g.drawString(font, "RIGHT SHIFT  •  CLOSE: ESC  •  CLICK MODULE TO TOGGLE",
                px + 170, py + ph - 22, MUTED, false);
    }

    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        int button = event.button();
        if (button != 0) return super.mouseClicked(event, doubleClick);
        int cy = py + 72;
        for (String cat : categories) {
            if (mx >= px + 8 && mx <= px + 145 && my >= cy && my <= cy + 27) {
                selected = cat; scroll = 0; return true;
            }
            cy += 34;
        }
        if (mx >= px + pw - 100 && my <= py + 55) { searching = true; return true; }

        List<Module> list = ModuleManager.in(category()).stream()
                .filter(m -> search.isBlank() || m.name().toLowerCase().contains(search.toLowerCase()))
                .toList();
        int start = Math.min(scroll, Math.max(0, list.size() - 8));
        for (int i = 0; i < Math.min(8, list.size() - start); i++) {
            int col = i / 4, row = i % 4;
            int x = px + 170 + col * 245, y = py + 91 + row * 73;
            if (mx >= x && mx <= x + 228 && my >= y && my <= y + 60) {
                Module module = list.get(start + i);
                if (module.name().equals("Panic")) ModuleManager.disableAll();
                else module.toggle();
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override public boolean charTyped(CharacterEvent event) {
        int cp = event.codepoint();
        if (searching && !Character.isISOControl(cp)) {
            search += new String(Character.toChars(cp));
            return true;
        }
        return super.charTyped(event);
    }

    @Override public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (searching && key == 259 && !search.isEmpty()) {
            search = search.substring(0, search.length() - 1); return true;
        }
        if (key == 256) {
            if (searching) { searching = false; search = ""; return true; }
            onClose(); return true;
        }
        if (key == 264) { scroll++; return true; }
        if (key == 265) { scroll = Math.max(0, scroll - 1); return true; }
        return super.keyPressed(event);
    }

    @Override public boolean isPauseScreen() { return false; }
}
