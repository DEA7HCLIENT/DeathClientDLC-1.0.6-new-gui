package br0.neverlose;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    static {
        // Safe client-side utilities, HUDs and training helpers.
        add("Aim Trainer", "Local aim-practice overlay; no automatic targeting", Module.Category.COMBAT);
        add("Click CPS", "Displays clicks per second", Module.Category.COMBAT);
        add("Reach Display", "Displays measured interaction distance", Module.Category.COMBAT);
        add("Hit Timing", "Practice timing indicator", Module.Category.COMBAT);
        add("Combo Counter", "Tracks consecutive hits", Module.Category.COMBAT);
        add("Target HUD", "Displays information about the current crosshair target", Module.Category.RENDER);
        add("Hit Color", "Changes the local hit feedback tint", Module.Category.RENDER);
        add("ESP", "Local entity highlighting for supported practice worlds", Module.Category.RENDER);
        add("Tracers", "Draws local visual guides to visible entities", Module.Category.RENDER);
        add("Name Tags", "Enhanced name labels", Module.Category.RENDER);
        add("China Hat", "Cosmetic player overlay", Module.Category.RENDER);
        add("Array List", "Shows enabled modules", Module.Category.RENDER);
        add("Keystrokes", "Displays movement key presses", Module.Category.RENDER);
        add("FPS", "Displays frames per second", Module.Category.RENDER);
        add("Coordinates", "Displays player coordinates", Module.Category.RENDER);
        add("Armor HUD", "Displays equipped armor", Module.Category.RENDER);
        add("Potion HUD", "Displays active status effects", Module.Category.RENDER);
        add("Inventory HUD", "Displays inventory contents", Module.Category.RENDER);
        add("Crosshair", "Custom crosshair", Module.Category.RENDER);
        add("Motion Blur", "Cosmetic motion effect", Module.Category.RENDER);
        add("Sprint", "Sprint state helper", Module.Category.MOVEMENT);
        add("Speedometer", "Displays movement speed", Module.Category.MOVEMENT);
        add("Direction HUD", "Displays facing direction", Module.Category.MOVEMENT);
        add("Safe Walk", "Practice-world edge warning", Module.Category.MOVEMENT);
        add("Jump Circle", "Landing position visualizer", Module.Category.MOVEMENT);
        add("Auto Sprint", "Convenience sprint toggle for supported local worlds", Module.Category.MOVEMENT);
        add("Inventory Move", "Allows inventory navigation with movement keys", Module.Category.PLAYER);
        add("Armor Warning", "Warns when equipped armor is low", Module.Category.PLAYER);
        add("Durability Alert", "Warns about low item durability", Module.Category.PLAYER);
        add("Effect Timer", "Shows remaining effect durations", Module.Category.PLAYER);
        add("Auto Eat Reminder", "Food-level reminder; does not consume items automatically", Module.Category.PLAYER);
        add("Totem Counter", "Displays totem count", Module.Category.PLAYER);
        add("Notifications", "Client notifications", Module.Category.MISC);
        add("Session Info", "Displays session statistics", Module.Category.MISC);
        add("Friend List", "Local friend labels", Module.Category.MISC);
        add("Config Manager", "Configuration profiles", Module.Category.MISC);
        add("HUD Editor", "Move and scale HUD elements", Module.Category.MISC);
        add("Panic", "Disables all enabled client modules", Module.Category.MISC);
    }

    private static void add(String name, String description, Module.Category category) {
        MODULES.add(new Module(name, description, category));
    }

    public static List<Module> all() {
        return Collections.unmodifiableList(MODULES);
    }

    public static List<Module> in(Module.Category category) {
        return MODULES.stream().filter(m -> m.category() == category).toList();
    }

    public static void disableAll() {
        MODULES.forEach(m -> m.setEnabled(false));
    }
}
